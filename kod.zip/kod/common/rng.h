#ifndef RNG_H
#define RNG_H

#include <stdint.h>
#include "stm32f4xx_rng.h"

uint32_t RNG_GetUInt32(void);
uint8_t RNG_GetUInt8(void);

#endif