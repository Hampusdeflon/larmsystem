#include <stdint.h>
#include <can.h>
#include <usart.h>

#define DEBUG

/*Compare arrays
 * @param a Array1
 * @param b Array2
 * @param length The number of elements known to be in both arrays
 * @author Martin Engström*/
uint8_t compareArrays(uint8_t a[], uint8_t b[], int length)
{
	for(int i = 0; i < length; i++) {
		if (a[i] != b[i]) {
			return 0;
		}
	}
	return 1;
}

/*Compare arrays
 * @param a Array1 copied to
 * @param b Array2 copied from
 * @param length The number of elements known to be in both arrays
 * @author Martin Engström*/
void copyArray(uint8_t a[], uint8_t b[], int length)
{
	for(int i = 0; i < length; i++) {
		a[i] = b[i];
	}
}

/*Convert MAC field to uint32_t
 * @param MAC a pointer to a buffer that should contain MAC address
 * @param n Value to convert to a field
 * @author Martin Engström*/
void uint32_storeMAC(uint8_t MAC[], uint32_t n)
{
	for(uint8_t i = 0; i < 4; i++) {
		// Shift byte into place, save only the first two bytes, and store it
		MAC[i] = (n >> 8*(3-i)) & 0xFF;
	}
}

/*Convert MAC field to uint32_t
 * @param buff Arbitrarily large buffer containing a 4 byte long MAC address
 * @param start Position of MAC in field (Last byte of MAC), 0 indexed
 * @return A converted MAC address
 * @author Martin Engström*/
uint32_t arrayMAC_2_int(uint8_t buff[], uint8_t start)
{
	uint32_t MAC = 0;
	// Start at the end of the MAC address and shift byte into place
	for(int i = start; i > (start - 4); i--) {
		MAC &= buff[i] << 8*(start - i);
	}
#ifdef DEBUG
	DUMP_int(MAC);
#endif
	return MAC;
}

/*Copy MAC from CANMsg to a buffer
 * @param MAC 4 byte long buffer where the MAC address is copied to
 * @param msg A CAN message that contains a MAC address at position "start"
 * @param start Position of MAC in field (Last byte of MAC), 0 indexed
 * @author Martin Engström*/
void collectMAC(uint8_t MAC[], CANMsg *msg, uint8_t start)
{
	uint8_t index = 3;
	for(int i = start; i > (start - 4); i--) {
		MAC[index--] = msg->buff[i];
	}
}
