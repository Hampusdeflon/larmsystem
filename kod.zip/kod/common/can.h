#ifndef CAN_H
#define CAN_H

#include <stdint.h>
#include "stm32f4xx.h"
#include "gpio.h"
#include "stm32f4xx_can.h"
#include "stm32f4xx_rcc.h"

#define	__CAN_TxAck			//make transmission block (wait) until another node is connected
#define __DUMP_ENABLED      // Comment out to disable deubug messages over USART
#define __IRQ_PRIORITY		2
#define	CAN1_IRQ_VECTOR		(0x2001C000+0x90)
#define __ENABLED_PRIORITY	3
#define MSG_TYPE_PERIPHERAL_DISCOVERY (0b1) //msg types from peripheral has peripheraal in the name
#define MSG_TYPE_PERIPHERAL_TYPE (0b10)
#define MSG_TYPE_PERIPHERAL_DEACTIVATE (0b11)
#define MSG_TYPE_PERIPHERAL_REQUEST (0b100)
#define MSG_TYPE_CENTRAL_PING (0b1)
#define MSG_TYPE_CENTRAL_CONFIGUR_DOOR (10)
#define MSG_TYPE_CENTRAL_ALARM_ACK (0b1000)
#define MSG_DIR (0b10000)

enum ALARM_TRIGGERED {
	ALARM_PASSIVE,
	ALARM_TRIGGERED
};
enum PERIPHERAL_TYPE {
	DOOR_ALARM,
	MOTION_SENSOR_ALARM,
	NOISE_MAKER
};
enum MOTION_ALARM_TYPE {
	MOTION,
	VIBRATION
};
enum MSG_DIRECTION {
	MSG_DIR_FROM_PERIPHERAL,
	MSG_DIR_FROM_CENTRAL
};

/*The general structure of a can message
 @author Martin Engström*/
typedef struct {
	uint8_t alarm : 1;  //If message is an alarm 0/1
	uint8_t dir : 1;    //If message is directed towards central unit 0/1
	uint8_t msgId : 4;  //Valid values: 0-15
	uint8_t nodeId : 5; //Valid values: 0-31
	uint8_t length : 4; //Valid values: 0-8
	uint8_t buff[8];    // A message carries at most 8 bytes of data
	uint16_t crc; // Error checking for debugging
} CANMsg;

typedef void (*VoidFunction)(void);
// Exported CAN functions
void can1_init(VoidFunction interrupt);
int can_receive(CANMsg *msg);
int can_send(CANMsg *msg);
void receiver(void);
void can_send_msg(uint8_t* AlarmMsg, uint8_t AlarmMsgId, uint8_t AlarmMsgNodeId, uint8_t AlarmMsgLength);
void peripheral_can_reciever();
uint8_t verify_CANMsg_validity(CANMsg*);

#endif
