#include <stdint.h>

uint32_t arrayMAC_2_int(uint8_t buff[], uint8_t start);
void collectMAC(uint8_t MAC[], CANMsg *msg, uint8_t start);
uint8_t compareArrays(uint8_t a[], uint8_t b[], int length);
void copyArray(uint8_t a[], uint8_t b[], int length);
