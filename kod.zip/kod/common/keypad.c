#include "keypad.h"


uint8_t state; //this variable makes sure that no key is read more than once

/*
 * author Houmam
 * */
void keypad_init(void) //configer the i/o pinns for the keyboard.
{
	GPIO_DeInit(GPIOD);
	GPIOD->MODER = 0x55000000;
	GPIOD->OTYPER &= 0x0F;
	GPIOD->PUPDR  = 0xAA;
	state = 0;
}

/*








    @@ -30,19 +32,13 @@ signed char ReadColumn() {

 * activaterow and readcolumn are used to determain wich key is pressed
 * author Houmam
 * */
void ActivateRow(uint8_t row)
{
	GPIOD->ODR = (0x10 << row) << 8;//first rwo has value 0. same with columns
}
signed char ReadColumn()
{
	uint8_t c = GPIOD->IDR >> 8;
	for(int bit = 0; bit < 4; bit++) {
		if((c >> bit) & 1) {
			return bit;
		}
	}
	return -1;
}
uint8_t kb()
{
	signed char column;
	volatile uint32_t x;
	for(int row = 0; row < 4; row++) {
		ActivateRow(row);
		x = 1000;
		while(x) {
			x--;
		}
		column = ReadColumn();
		if(column+1) {
			ActivateRow(0);
			return (row << 2)+(column);







		}
	}
	ActivateRow(0);
	return 0xFF;
}

uint8_t keyb_enhanced(void)
{
	uint8_t k = kb();
	if(state) {
		if(k != 0xFF) {
			state = 0;
			return k;
		}
		return 0xFF;
	}
	if((k == 0xFF)) {
		state = 1;
	}
	return 0xFF;
}


//this functin return the true key printed on the keypad
//author Houmam
uint8_t getKey()
{
	uint8_t keys[] = {1, 2, 3, 'A', 4, 5, 6, 'B', 7, 8, 9, 'C', '*', 0, '#', 'D'};
	uint8_t key = keyb_enhanced();
	if(key != 255) {
		return keys[key];
	}
	return 255;
}
