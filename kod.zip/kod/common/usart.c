/*
 * usart initialising functions and other writing  and reading functions
 */


#include "usart.h"

/*Writes 8 bytes from one buffer to another
 *@param b1 New buffer
 *@param b2 Copied buffer
 *@author Martin Engström*/
void duplicate_buff8(uint8_t * b1, uint8_t * b2)
{
	for(uint8_t i = 0; i < 8; i++) {
		b1[i] = b2[i];
	}
}

//author Houmam

void _outchar( char c )
{
	/* write character to usart1 */
	while (( USART1->SR & 0x80)==0);
	USART1->DR = (unsigned short) c;
	if( c == '\n')
		_outchar('\r');
}

char _tstchar(void)
{
	/* see if character arrived at usart1,
	    if not, return 0
	    else return character
	    */
	if( (USART1->SR & 0x20)==0)
		return 0;
	return (char) USART1->DR;
}

//author Houmam

char _getchar(void)
{
	/* wait until character arrived at usart1,
	    return character
	    */
	while( (USART1->SR & 0x20)==0)
		;
	return (char) USART1->DR;
}

/*returns digit input from USART
 *@param integer Integer to be printed
 *@author Hampus de Flon*/
uint8_t _getdigit()
{
	/* wait until character arrived at usart1,
	return character
	*/
	while((USART1->SR & 0x20)==0);
	return ((uint8_t)((USART1->DR) - 48));
}
//author Houmam
void usart_send(char* s)
{
	while (*s != '\0')
		_outchar(*(s++));
}
//author Houmam
void DUMP(char *s)
{
#ifdef __DUMP_ENABLED
	usart_send(s);
#endif
}

/*Prints integers to USART
 *@param integer Integer to be printed
 *@author Hampus de Flon*/
void DUMP_int(int integer)
{
	char buf[8];
	int2str(integer, buf );
	DUMP(buf);
}

/* Convert int to string representing the unsigned value
 * @param n Value to be converted
 * @param str Where the resulting string is stored
 * @author Martin Engström
 * */
void int2str(int n, char str[])
{
	int nDigits = get_int_len(n);
	str[nDigits] = '\0';
	for(int i = nDigits - 1; i >= 0; i--) { // Loop over all digits backwards
		str[i] = ( (n % 10) + 48 ); // Convert to ASCII code and store in str[]
		n /= 10;
	}
}
/* Get number of digits of integer
 * @param int Value the length is taken over
 * @author Martin Engström
 * */
int get_int_len (int n)
{
	int l=1;
	while(n>9) {
		l++;
		n/=10;
	}
	return l;
}
uint32_t pow(int num)
{
	int tio = 1;
	for(int i = 0; i < num; i++) {
		tio = 10 * tio;
	}
	return tio;
}
uint32_t _getint()
{

	uint32_t num = 0;
	uint8_t digit;
	for(int i = 0; i < 10; i++) {
		digit = _getdigit();
		if(digit == 218) {
			return num;
		}
		DUMP_int(digit);
		num = (num * 10) + digit;
	}
	return num;
}
