#ifndef DEBUG_H
#define DEBUG_H

#include "can.h"
void Debug_CANmsg_DUMP(CANMsg*);
void Debug_CANmsgRCV_dummy_handler(void);
void Debug_dump_MAC(uint8_t*);

#endif
