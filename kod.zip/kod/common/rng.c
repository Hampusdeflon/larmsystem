#include "rng.h"

void RNG_Init(void) {
  RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_RNG, ENABLE);
  RNG_Cmd(ENABLE);
}

uint32_t RNG_GetUInt32(void) {
  while(RNG_GetFlagStatus(RNG_FLAG_DRDY) == RESET);

  return RNG_GetRandomNumber();
}

uint8_t RNG_GetUInt8(void) {
  return RNG_GetUInt32() & 8;
}