#include <peripheral.h>
#include <timers.h>
// Initiate peripheral with MAC = 0, nodeId = 0, PERIPHERAL_TYPE = 0
UNIT peripheral = {{0,0,0,0},0,0,0,0};
uint8_t discover_failure;
uint8_t requested_nodeId;
volatile uint64_t Ticks;
