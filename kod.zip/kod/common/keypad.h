#include <stdint.h>
#include "gpio.h"
#include "usart.h"

uint8_t getKey();
uint8_t kb();
void keypad_init(void);
