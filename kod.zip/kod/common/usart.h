#ifndef USART_H
#define USART_H

#include "stm32f4xx_usart.h"
#include <stdint.h>
#define	__CAN_TxAck
#define __DUMP_ENABLED

void _outchar( char c );
char _tstchar(void);
char _getchar(void);
void usart_send(char* s);
void DUMP(char *s);
void DUMP_int(int integer);
void int2str(int n, char str[]);
uint32_t _getint();

#endif
