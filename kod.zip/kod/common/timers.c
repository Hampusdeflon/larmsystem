
#include <stdint.h>
#include <timers.h>
#include <stm32f4xx_rcc.h>
#include <stm32f4xx_tim.h>
#include <core_cm4.h> // Can be found in /kod/stmlib/CMSIS/Include/core_cm4.h
#include <misc.h>

/*
 * Initialize a SysTick triggered interrupt with specified frequency.
 * @param frequency The frequency the interrupt should be triggered (Hz).
 * @param handler The interrupt handler function.
 * @author Leopold Wigbratt
 */
void TIMERS_InitSysTick(uint32_t frequency, void (*handler) (void))
{
	SysTick_Config(168000000/frequency);

	NVIC_SetPriority(SysTick_IRQn, 0);

	*((void (**) (void)) 0x2001C03C) = handler;
}

/*
 * A general function for initializing TIM2-TIM5 timers with interrupt handlers.
 * @param TIMx The TIM to be configured (2-5).
 * @param prescaler Divide the base clock (84 MHz) by this value.
 * @param period The amount of cycles of the scaled main clock should constitute one period.
 * @param handler The interrupt handler function.
 * @author Martin Engström, Hampus, Leopold Wibratt
 */
void TIMERS_InitTIM(uint8_t TIMx, uint16_t prescaler, uint32_t period, void (*handler) (void))
{
	uint32_t RCC_APB1Periph_TIMx;
	uint8_t NVIC_IRQChannel;
	TIM_TypeDef *TIM;

	switch (TIMx) {
		default:
		case 2:
			RCC_APB1Periph_TIMx = RCC_APB1Periph_TIM2;
			NVIC_IRQChannel = TIM2_IRQn;
			TIM = TIM2;
			break;
		case 3:
			RCC_APB1Periph_TIMx = RCC_APB1Periph_TIM3;
			NVIC_IRQChannel = TIM3_IRQn;
			TIM = TIM3;
			break;
		case 4:
			RCC_APB1Periph_TIMx = RCC_APB1Periph_TIM4;
			NVIC_IRQChannel = TIM4_IRQn;
			TIM = TIM4;
			break;
		case 5:
			RCC_APB1Periph_TIMx = RCC_APB1Periph_TIM5;
			NVIC_IRQChannel = TIM5_IRQn;
			TIM = TIM5;
			break;
	}

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIMx, ENABLE);

	*((void (**) (void)) 0x2001C0B0) = handler;

	TIM_TimeBaseInitTypeDef timer_init_structure;

	timer_init_structure.TIM_Prescaler = prescaler - 1;
	timer_init_structure.TIM_Period = period - 1;
	timer_init_structure.TIM_CounterMode = TIM_CounterMode_Up;
	timer_init_structure.TIM_ClockDivision = TIM_CKD_DIV1;

	TIM_TimeBaseInit(TIM, &timer_init_structure);
	TIM_ITConfig(TIM, TIM_IT_Update, ENABLE);

	NVIC_InitTypeDef nvicStructure;
	nvicStructure.NVIC_IRQChannel = NVIC_IRQChannel;
	nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicStructure.NVIC_IRQChannelSubPriority = 0;
	nvicStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicStructure);

	TIM_ClearITPendingBit(TIM, TIM_IT_Update);

	TIM_Cmd(TIM, ENABLE);
}

/*
 * A general function for deinitializing TIM2-TIM5 timers with interrupt handlers.
 * @param TIMx The TIM to be disabled (2-5).
 * @author Martin Engström, Hampus, Leopold Wibratt
 */
void TIMERS_DeinitTIM(uint8_t TIMx)
{
	uint32_t RCC_APB1Periph_TIMx;
	TIM_TypeDef *TIM;

	switch (TIMx) {
		default:
		case 2:
			TIM = TIM2;
			break;
		case 3:
			TIM = TIM3;
			break;
		case 4:
			TIM = TIM4;
			break;
		case 5:
			TIM = TIM5;
			break;
	}

	TIM_ITConfig(TIM, TIM_IT_Update, DISABLE);
	TIM_Cmd(TIM, DISABLE);
}

/*Initiate TIM2 with interrupts every 100ms
 * @param handler A void function pointer to the interrupt handler
 * @author Martin Engström, Hampus de Flon*/
void init_tim2(void (*handler) (void))
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	// set TIM2 Interrupt handler
	*((void (**) (void)) 0x2001C0B0) = handler;

	TIM_TimeBaseInitTypeDef timer_init_structure;

	// Set interrupt delay to happen every 					100 milli second
	timer_init_structure.TIM_Prescaler = (4200-1);
	timer_init_structure.TIM_Period = (2000-1);
	timer_init_structure.TIM_CounterMode = TIM_CounterMode_Up;
	timer_init_structure.TIM_ClockDivision = TIM_CKD_DIV1;

	TIM_TimeBaseInit(TIM2, &timer_init_structure);
	TIM_ITConfig(TIM2,TIM_IT_Update, ENABLE);

	// Enable tim2 interrupts
	NVIC_InitTypeDef nvicStructure;
	nvicStructure.NVIC_IRQChannel = TIM2_IRQn;
	nvicStructure.NVIC_IRQChannelPreemptionPriority = 0;
	nvicStructure.NVIC_IRQChannelSubPriority = 0;
	nvicStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&nvicStructure);

	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

	TIM_Cmd(TIM2, ENABLE);
}



// Delay functions using systick

void delay_250ns(void)
{
	*STK_CTRL = 0;
	*STK_LOAD = (168 / 4) - 1;
	*STK_VAL = 0;
	*STK_CTRL = 5;

	while (!(*STK_CTRL & 0x10000));

	*STK_CTRL = 0;
}

void delay_micro(uint32_t us)
{

	while (us--) {
		delay_250ns();
		delay_250ns();
		delay_250ns();
		delay_250ns();
	}
}

void delay_milli(uint32_t ms)
{
	delay_micro(ms * 1000);
}
