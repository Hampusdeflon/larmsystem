#include <stdint.h>
#include <peripheral.h>
/*Convert Set peripherals MAC field
 * @param buff Containing 4 byte long MAC address
 * @author Martin Engström*/
void setPeripheralMAC(uint8_t MAC[])
{
	for(uint8_t i = 0; i < 4; i++) {
		(peripheral.MAC)[i] = MAC[i];
	}
}
