#include <stdint.h>

#define MAX_PIN_ATTEMPTS 3

typedef struct {
	uint16_t PIN; // 4 byte code
	uint8_t expected_d_alarm; // Number of expected door alarms
	uint8_t expected_m_alarm; // Number of expected motion alarms
	uint8_t connected_d_alarm;// Number of connected door alarms
	uint8_t connected_m_alarm;// Number of connected motion alarms
} Central_u, *PCentral_u;

extern Central_u conf;
