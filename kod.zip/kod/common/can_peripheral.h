
#include <stdint.h>


uint8_t alarm_is_acked;

void peripheral_can_send(uint8_t *msg, uint8_t msg_size, uint8_t is_alarm, uint8_t is_ping);
void peripheral_can_receiver();
void DISCOVER();
void peripheral_send_door_alarm();
void CAN_PERIPHERAL_start_motion_alarm(uint8_t vib_or_motion);
