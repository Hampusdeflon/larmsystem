#ifndef RANDOM_H
#define RANDOM_H

#include <stdint.h>
uint32_t random_uint32_t( void );
uint8_t random_uint8_t( void );

#endif