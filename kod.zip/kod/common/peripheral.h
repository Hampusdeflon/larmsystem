#include <stdint.h>
#include <can.h>
// Comment out if you want to set the MAC yourself
//#define DYNAMIC_MAC
#define MAX_DISCOVER_FAILURE 20

typedef struct {
	uint8_t MAC[4];
	uint8_t nodeId;
	uint8_t isConnected;
	uint8_t DISCOVER_started; // DISCOVER protocol started : 1, not started : 0
	enum PERIPHERAL_TYPE unitType;
} UNIT, *PUNIT;

extern UNIT peripheral;
extern uint8_t discover_failure;
extern uint8_t requested_nodeId;
void setPeripheralMAC(uint8_t MAC[]);
