#ifndef SYSTIC_H
#define SYSTIC_H

/*
 * systic configeration and funktiones header file
 * @author Houmam Kadamani
 */
#include <stdint.h>
#include "stm32f4xx_syscfg.h"

void TIMERS_InitTIM(uint8_t TIMx, uint16_t base_clock, uint32_t multiplier, void (*handler) (void));
void init_tim2(void (*handler) (void));
void TIMERS_DeinitTIM(uint8_t TIMx);
void TIMERS_InitSysTick(uint32_t frequency, void (*handler) (void));
extern volatile uint64_t Ticks;

/*Delay / SysTick: */
#define SysTick			  0xE000E010
#define STK_CTRL		  ((volatile unsigned int *)      (SysTick))
#define STK_LOAD		  ((volatile unsigned int *)     (SysTick+0x04))
#define STK_VAL			  ((volatile unsigned int *)    (SysTick+0x08))
#define STK_CALIB		  ((volatile unsigned int *)    (SysTick+0x0C))

#endif
