/*#include "door_alarm.h"

// Type of message sent from central unit to door alarm
typedef enum {
    LOCK_DOOR,
    UNLOCK_DOOR,
    ENABLE_DOOR,
    DISABLE_DOOR,
	CONFIGURATION
} CAN_DOOR_ALARM_MESSAGE_TYPE;


// The complete body of a message from central unit to door alarm
typedef struct {
    CAN_DOOR_ALARM_MESSAGE_TYPE message_type;
    union {
        DOOR_ALARM_CONFIG config; // The config struct passed to DOOR_ALARM_Init
        uint8_t door_index; // NBCD encoded index
    };
} CAN_DOOR_ALARM_MESSAGE;*/
 
