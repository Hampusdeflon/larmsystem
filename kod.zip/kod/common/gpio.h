#ifndef GPIO_H
#define GPIO_H

#include <stdint.h>
#include "stm32f4xx_gpio.h"
#include "stm32f4xx.h"

void GPIO_InitGPIOPins(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef mode, GPIOMode_TypeDef otype, GPIOPuPd_TypeDef pupd, uint16_t pins);

void GPIO_DeInitGPIO(uint8_t GPIO);

void GPIO_InitGPIO(uint8_t GPIO, GPIOMode_TypeDef mode, GPIOMode_TypeDef otype, GPIOPuPd_TypeDef pupd, uint16_t pins);

#endif