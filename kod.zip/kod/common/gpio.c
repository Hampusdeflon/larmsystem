#include "gpio.h"

// The index of the array is mapped to a GPIO pin (uint32_t).
static uint32_t GPIO_PinMap[] = {
    GPIO_Pin_0,
    GPIO_Pin_1,
    GPIO_Pin_2,
    GPIO_Pin_3,
    GPIO_Pin_4,
    GPIO_Pin_5,
    GPIO_Pin_6,
    GPIO_Pin_7,
    GPIO_Pin_8,
    GPIO_Pin_9,
    GPIO_Pin_10,
    GPIO_Pin_11,
    GPIO_Pin_12,
    GPIO_Pin_13,
    GPIO_Pin_14,
    GPIO_Pin_15
};

// The index in the array is mapped to a GPIO_TypeDef pointer.
static GPIO_TypeDef *GPIO_LetterMap[] = {
    GPIOA,
    GPIOB,
    GPIOC,
    GPIOD,
    GPIOE
};

/*
 * Configure a range of pins on a GPIO port with a specified mode.
 * @param GPIOx The GPIO port to be configured.
 * @param mode The mode that the pins should be set to.
 * @param otype The OType the pins should be set to.
 * @param pupd The PuPd mode the pins should be set to.
 * @param pins Each bit is mapped to a pin, where the LSB is pin 0. A 1 signifies that the corresponding pin should be configured.
 * @author Leopold Wigbratt
 */
//void GPIO_InitGPIOPins(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef mode, uint8_t pin_start, uint8_t pin_end) {
//  GPIO_InitTypeDef GPIO_InitStructure;
//  GPIO_StructInit(&GPIO_InitStructure);
//
//  for (uint8_t pin = pin_start; pin <= pin_end; pin++) {
//    GPIO_InitStructure.GPIO_Pin = GPIO_PinMap[pin];
//    GPIO_InitStructure.GPIO_Mode = mode;
//    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_Init(GPIOx, &GPIO_InitStructure);
//  }
//}

void GPIO_InitGPIOPins(GPIO_TypeDef* GPIOx, GPIOMode_TypeDef mode, GPIOMode_TypeDef otype, GPIOPuPd_TypeDef pupd, uint16_t pins) {
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_StructInit(&GPIO_InitStructure);


  for (uint8_t n = 0; n <= 16; n++) {
    if (pins & 1) {
      GPIO_InitStructure.GPIO_Pin = GPIO_PinMap[n];
      GPIO_InitStructure.GPIO_Mode = mode;
      GPIO_InitStructure.GPIO_OType = otype;
      GPIO_InitStructure.GPIO_PuPd = pupd;
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_Init(GPIOx, &GPIO_InitStructure);
    }

    pins >>= 1;

  }
}

/*
 * Deinitialize GPIO ports
 * @param GPIO The five least significant bits are mapped to each GPIO port, where the LSB is GPIOA. A 1 signifies that the port should to be deinitialized.
 * @author Leopold Wigbratt
 */
void GPIO_DeInitGPIO(uint8_t GPIO) {
  for (uint8_t n = 0; n < 5; n++) {
    if (GPIO & 1) {
      GPIO_DeInit(GPIO_LetterMap[n]);
    }

    GPIO >>= 1;
  }
}

/*
 * Configure a range of pins on GPIO ports with a specified mode.
 * @param GPIO The five least significant bits are mapped to each GPIO port, where the LSB is GPIOA. A 1 signifies that the port should to be configured.
 * @param mode The mode that the pins should be set to.
 * @param pin_start The start index of the range of pins to be configured (zero-indexed).
 * @param pin_end The end index (inclusive) of the range of pins to be configured (zero-indexed).
 * @author Leopold Wigbratt
 */
void GPIO_InitGPIO(uint8_t GPIO, GPIOMode_TypeDef mode, GPIOMode_TypeDef otype, GPIOPuPd_TypeDef pupd, uint16_t pins) {
  for (int n = 0; n < 5; n++) {
    if (GPIO & 1) {
      GPIO_InitGPIOPins(GPIO_LetterMap[n], mode, otype, pupd, pins);
    }

    GPIO >>= 1;
  }
}
