
#include <debug.h>
#include <usart.h>

/*Dump MAC address
 * @param MAC a 4 byte long field
 * @author Martin Engström*/
void Debug_dump_MAC(uint8_t MAC[])
{
	for(int i = 0; i < 4; i++) {
		DUMP("\n");
		DUMP_int(MAC[i]);
	}
}

/* Dump can message to USART1
 * @param msg A message for can of any type
 * @author Martin Engström
 * */
void Debug_CANmsg_DUMP(CANMsg *msg)
{
	char tmpStr[10];

	int2str(msg->alarm, tmpStr);
	DUMP("\n alarm: ");
	DUMP(tmpStr);

	int2str(msg->dir, tmpStr);
	DUMP("\n direction: ");
	DUMP(tmpStr);

	int2str(msg->msgId, tmpStr);
	DUMP("\n msgId: ");
	DUMP(tmpStr);

	int2str(msg->nodeId, tmpStr);
	DUMP("\n nodeId: ");
	DUMP(tmpStr);

	int2str(msg->length, tmpStr);
	DUMP("\n length: ");
	DUMP(tmpStr);

	//DUMP("\n message: ");
	//DUMP(msg->buff);

	//int2str(msg->crc, tmpStr);
	//DUMP("\n CRC");
	//DUMP(tmpStr);
}

/* Dummy function to handle received messages for testing the receive function
 * @author Martin Engström
 * */
void Debug_CANmsgRCV_dummy_handler()
{
	CANMsg msg;
	can_receive(&msg);
}


void DEBUG_vibration_sensor(void)
{
	//motion_sensor_alarm_init();
	char str[8];
	uint8_t value;
	while (1) {
		//value = get_vibration_sensor_value();
		int2str(value, str);
		DUMP(str);
		delay_milli(100);
	}
}
