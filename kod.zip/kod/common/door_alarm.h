#ifndef DOOR_ALARM_H
#define DOOR_ALARM_H

#include <stdint.h>
#include "stm32f4xx_gpio.h"
#include "stm32f4xx.h"
#include "stm32f4xx_tim.h"
#include "gpio.h"
#include "can.h"
#include "timers.h"
#include "usart.h"
#include "can_peripheral.h"

typedef struct {
    uint16_t enable_doors;
    uint8_t open_door_s;
    uint8_t local_alarm_s;
} DOOR_ALARM_CONFIG;

void DOOR_ALARM_Init(DOOR_ALARM_CONFIG *config);

void DOOR_ALARM_DisableAlarm(uint16_t disable_doors);

void DOOR_ALARM_Run(void);

void set_local_alarm(uint16_t doors);

void DOOR_ALARM_LockDoor(uint8_t door_index);

void DOOR_ALARM_UnlockDoor(uint8_t door_index);

void DOOR_ALARM_EnableDoor(uint8_t door_index);

void DOOR_ALARM_DisableDoor(uint8_t door_index);

void remove_central_alarm(void);

uint16_t poll_pins(void);

#endif