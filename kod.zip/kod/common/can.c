#include "can.h"

// Houmam...test reciever
void receiver(void)
{
	DUMP("CAN message received: ");

	CANMsg msg;
	if (can_receive(&msg))
		DUMP((char*)msg.buff);
	else
		DUMP("***Error: Something went wrong :(");
}

#define DEBUG_H


// Initialize CAN controller for CAN1
// interrupt is called each time a message is ready to be received
// Houmam
//
void can1_init(VoidFunction interrupt)
{

	CAN_FilterInitTypeDef  CAN_FilterInitStructure;

	GPIO_DeInit( GPIOB );
	CAN_DeInit( CAN1 );
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_CAN1, ENABLE );
	RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOB, ENABLE);

	/* Connect CAN1 pins to AF */
	/* PB9 - CAN1 TX */
	/* PB8 - CAN1 RX  */
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_CAN1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_CAN1);

	GPIO_InitGPIOPins(GPIOB, GPIO_Mode_AF, GPIO_OType_PP, GPIO_PuPd_NOPULL, (1 << 9));

	GPIO_InitGPIOPins(GPIOB, GPIO_Mode_AF, GPIO_Mode_IN, GPIO_PuPd_UP, (1 << 8));

	GPIO_InitGPIOPins(GPIOB, GPIO_Mode_AF, GPIO_OType_PP, GPIO_PuPd_NOPULL, (1 << 6));

	GPIO_InitGPIOPins(GPIOB, GPIO_Mode_AF, GPIO_Mode_IN, GPIO_PuPd_UP, (1 << 5));


	/* CAN filter init */
	CAN_FilterInitStructure.CAN_FilterNumber = CAN_Filter_FIFO0;
	CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
	CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
	CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
	CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000; // 0 in a position means ignore that bit
	CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment = 0;
	CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
	CAN_FilterInit(&CAN_FilterInitStructure);

	CAN_InitTypeDef CAN_InitStructure;
	CAN_InitStructure.CAN_TTCM = DISABLE; // time-triggered communication mode = DISABLED
	CAN_InitStructure.CAN_ABOM = DISABLE; // automatic bus-off management mode = DISABLED
	CAN_InitStructure.CAN_AWUM = DISABLE; // automatic wake-up mode = DISABLED
	CAN_InitStructure.CAN_NART = DISABLE; // non-automatic retransmission mode = DISABLED
	CAN_InitStructure.CAN_RFLM = DISABLE; // receive FIFO locked mode = DISABLED
	CAN_InitStructure.CAN_TXFP = DISABLE; // transmit FIFO priority = DISABLED
	CAN_InitStructure.CAN_Mode = CAN_Mode_Normal; // normal CAN mode
	//
	// 42 MHz clock on APB1
	// Prescaler = 7 => time quanta tq = 1/6 us
	// Bit time = tq*(SJW + BS1 + BS2)
	// See figure 346 in F407 - Reference Manual.pdf
	//
	CAN_InitStructure.CAN_SJW = CAN_SJW_1tq; // synchronization jump width = 1
	CAN_InitStructure.CAN_BS1 = CAN_BS1_3tq;
	CAN_InitStructure.CAN_BS2 = CAN_BS2_4tq;
	CAN_InitStructure.CAN_Prescaler = 7; // baudrate 750kbps

	if (CAN_Init(CAN1, &CAN_InitStructure) == CAN_InitStatus_Failed)
		DUMP("CAN #1 Init failed!");
	else
		DUMP("CAN #1 Init successful!");

	*((void (**)(void) ) CAN1_IRQ_VECTOR ) = interrupt;

	__set_BASEPRI(__ENABLED_PRIORITY << (8 - __NVIC_PRIO_BITS));
	NVIC_SetPriority( CAN1_RX0_IRQn, __IRQ_PRIORITY);
	NVIC_EnableIRQ( CAN1_RX0_IRQn);
	CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);
}


//
// Read a message from the CAN bus and copy it to the supplied message data structure
// Houmam
int can_receive(CANMsg *msg)
{
	// Debug code : Print received message to USART1
	uint8_t index;
	CanRxMsg RxMessage;

	if (CAN_GetFlagStatus( CAN1, CAN_FLAG_FMP0) != SET)  // Data received in FIFO0
		return 0;


	CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);
	msg->alarm = (RxMessage.StdId >> 10) & 1;
	msg->dir = (RxMessage.StdId >> 9) & 1;
	msg->msgId  = (RxMessage.StdId >> 5) & 0xF;
	msg->nodeId = RxMessage.StdId & 0x1F;
	msg->length = (RxMessage.DLC & 0x0F);

	for (index = 0; index < msg->length; index++) {
		// Get received data
		msg->buff[index] = RxMessage.Data[index];
	}

	return 1;
}

//
// Copy the given message to a transmit buffer and send the message
// Houmam
int can_send(CANMsg *msg)
{
	uint8_t index;
	CAN_TypeDef* canport = CAN1;
	CanTxMsg TxMessage;
	uint8_t TransmitMailbox = 0;

	//set the transmit ID, standard identifiers are used, combine IDs
	TxMessage.StdId = (msg->alarm<<10) + (msg->dir<<9) + (msg->msgId<<5) + msg->nodeId;
	TxMessage.RTR = CAN_RTR_Data;
	TxMessage.IDE = CAN_Id_Standard;
	if (msg->length > 8)
		msg->length = 8;
	TxMessage.DLC = msg->length; // set number of bytes to send

	for (index = 0; index < msg->length; index++) {
		TxMessage.Data[index] = msg->buff[index]; //copy data to buffer
	}

	TransmitMailbox = CAN_Transmit(canport, &TxMessage);

	if (TransmitMailbox == CAN_TxStatus_NoMailBox) {
		DUMP("CAN TxBuf full!\n\r");
		return 1;
	}

#ifdef __CAN_TxAck
	while (CAN_TransmitStatus(canport, TransmitMailbox) == CAN_TxStatus_Pending) ;

	if (CAN_TransmitStatus(canport, TransmitMailbox) == CAN_TxStatus_Failed) {
		DUMP("CAN Tx fail!\n\r");
		return 1;
	}
#endif

	return 0;
}
/*
 * this function creates a massage to send via can
 * set sixth bit in alarmmsgid to 0 if the massage is an allarm and 1 if it's something else
 * for ping massages set bit 4 to 1
 * set bit 5 to 0 if the massage ment to centralenhet and 1 if it's from centralenheten
 * alarmMsgLength msg length in bytes
 * author Houmam
 * */
void can_send_msg(uint8_t* AlarmMsg, uint8_t AlarmMsgId, uint8_t AlarmMsgNodeId, uint8_t AlarmMsgLength)
{
	CANMsg msg;
	msg.msgId = AlarmMsgId << 5;
	msg.nodeId = AlarmMsgNodeId;
	msg.length = AlarmMsgLength;

	for (int i = 0; i < AlarmMsgLength ; i++) {
		msg.buff[i] = AlarmMsg++;
	}

	can_send(&msg);
}

/* Verify the validity of a CANMsg
 * @param msg CANMsg of any type
 * @return 0 : Failed test, 1 : Passed test
 * @author Martin Engström
 * */
uint8_t verify_CANMsg_validity(CANMsg* msg)
{
	uint8_t alarm = msg->alarm;
	uint8_t direction = msg->dir;
	uint8_t type = msg->msgId;
	uint8_t nodeId = msg->nodeId;
	uint8_t length = msg->length;
	// Verify that the nodeId and length are within valid values
	if(nodeId > 31 || length > 8) {
		return 0;
	}

	// Verify that the message fits the message type structure
	switch(type) {
		case 0: // Discover
			return(alarm == ALARM_PASSIVE &&
			       direction == MSG_DIR_FROM_PERIPHERAL &&
			       nodeId == 31 &&
			       length == 0);
			break;
		case 1: // Offer
			return(alarm == ALARM_PASSIVE &&
			       direction == MSG_DIR_FROM_CENTRAL &&
			       nodeId == 0 &&
			       length == 1);
			break;
		case 2: // NodeId Request
			return(alarm == ALARM_PASSIVE &&
			       direction == MSG_DIR_FROM_PERIPHERAL &&
			       (nodeId > 0 && nodeId < 31) &&
			       length == 5);
			break;
		case 3: // ACK/NAK
			return(alarm == ALARM_PASSIVE &&
			       direction == MSG_DIR_FROM_CENTRAL &&
			       nodeId == 0 &&
			       length == 5);
			break;
		case 4: // motion triggers alarm
			return (alarm == ALARM_TRIGGERED &&
			        direction == MSG_DIR_FROM_PERIPHERAL &&
			        (nodeId > 0 && nodeId < 31) &&
			        length == 1);
			break;
		case 5: // motion triggers alarm
			return (alarm == ALARM_TRIGGERED &&
			        direction == MSG_DIR_FROM_PERIPHERAL &&
			        (nodeId > 0 && nodeId < 31) &&
			        length == 4);
			break;
		case 6: // PING
			return(alarm == ALARM_PASSIVE &&
			       (direction == MSG_DIR_FROM_CENTRAL | direction == MSG_DIR_FROM_PERIPHERAL) &&
			       nodeId < 31 &&
			       length == 5);
			break;
		case 7: // Central sends sesnititity to motion
			return (alarm == ALARM_PASSIVE &&
			        direction == MSG_DIR_FROM_CENTRAL &&
			        nodeId == 0 &&
			        length == 1);
			break;
		case 8: // central acknowlages alarm from peripheral
			return (alarm == ALARM_TRIGGERED &&
			        direction == MSG_DIR_FROM_CENTRAL &&
			        nodeId == 0 &&
			        length == 0);
			break;
		case 9: // central READY
			return (alarm == ALARM_PASSIVE &&
			        direction == MSG_DIR_FROM_CENTRAL &&
			        nodeId == 0 &&
			        length == 0);
			break;
		case 10: // Door alarm
			return (alarm == ALARM_PASSIVE &&
			        direction == MSG_DIR_FROM_CENTRAL &&
			        nodeId == 0 &&
			        length == 4);
			break;
	}
	return 0;
}
