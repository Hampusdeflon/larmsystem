#include "random.h"
static uint32_t RandomState = 1784081117;
/* Generate a random 32-bit int
 * @author Martin Engström
 * */
uint32_t random_uint32_t( void )
{
	uint32_t result = RandomState;
	result ^= result << 13;
	result ^= result >> 17;
	result ^= result << 5;
	RandomState = result;
	return result;
}

/* Generate a random 8-bit int
 * @author Martin Engström
 * */
uint8_t random_uint8_t( void )
{
	uint8_t result = random_uint32_t();
	return result;
}
