#ifndef DOOR_ALARM_TEST_H
#define DOOR_ALARM_TEST_H

#include <stdint.h>
#include "door_alarm.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx.h"
#include "../common/gpio.h"

void DOOR_ALARM_TEST_GPIOInit(void);
void DOOR_ALARM_TEST_Diodes(void);
void DOOR_ALARM_TEST_LocalAlarm(void);
void DOOR_ALARM_TEST_Complete(void);
void DOOR_ALARM_TEST_UnlockDoor(void);

#endif