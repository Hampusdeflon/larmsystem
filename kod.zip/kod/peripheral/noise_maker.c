/*@file    noise_maker.c
* @author  Martin Engström
* @version V2
* @date    16-September-2021
* @brief   This file provides functions to manage the
* noise maker peripheral. The noise maker can be configured
* to send out data at 5 different speeds through the CAN-bus
* to test the error-handling functionality of the central unit.
*/


#include "noise_maker.h"
#include <timers.h>
#include <stm32f4xx_tim.h>

// 6 different speeds for the data output | Valid values: 0 - 5
// Higher value means faster transmission with the exception of 5 which is extremely slow.
static uint8_t NoiseStatus = 5;

/* Generate a random message and send it out on the CAN bus
 * @author Martin Engström
 * */
void noise_maker_send()
{
	CANMsg msg;
	msg.alarm = random_uint8_t() >> 7;
	msg.dir = random_uint8_t() >> 7;
	msg.msgId = random_uint8_t() >> 2;
	msg.nodeId = random_uint8_t() >> 3;
	msg.length = random_uint8_t() >> 4;
	for (int i = 0; i < 8; i++) {
		msg.buff[i] = random_uint8_t();
	}
	DUMP("Noise");
	can_send(&msg);

}

/* Handle SysTick interrupt for noise maker
 * @author Martin Engström
 * */
static volatile uint32_t seconds = 0;
void noise_handler()
{
	Ticks++;
	// Data is sent at different rates depending on NoiseStatus, one message every:
	switch(NoiseStatus) {
		case 0: // 10 seconds
			if(Ticks % 1000000 == 0) {
				seconds++;
				if(seconds >= 10) {
					seconds = 0;
					noise_maker_send();
				}
			}
			break;
		case 1: // 1 second
			if(Ticks % 1000000 == 0) {
				noise_maker_send();
			}
			break;
		case 2 : // 100ms
			if(Ticks % 100000 == 0) {
				noise_maker_send();
			}
			break;
		case 3: // 1ms
			if(Ticks % 1000 == 0) {
				noise_maker_send();
			}
			break;
		case 4: // 10us
			if(Ticks % 10 == 0) {
				noise_maker_send();
			}
			break;
		case 5: // 1us
			noise_maker_send();
			break;
	}
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
}

/* Initialize the noise maker to send noise on CAN bus
 * @author Martin Engström
 * */
void noise_maker_init( void )
{
	// setting up TIM2 interrupts 1us delay
	TIMERS_InitTIM(2, 84, 1, noise_handler);
}
