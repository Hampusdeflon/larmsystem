#include <stdint.h>
#include <can.h>
#include <peripheral.h>
#include <can_peripheral.h>
#include "usart.h"

#include "door_alarm_test.h"

#include "motion_alarm.h"


/*When initiating the peripheral the program will wait until the node
is connected, if MAX_DISCOVER_FAILURE is reached while setting up
the node, the program will enter a failure state.

In this case either the central unit isn't reachable or
the MAC address is poorly configured.*/

//Change value to run code for motion sensor alarm or door alarm
#define CURRENT_PERIPHERAL_TYPE MOTION_SENSOR_ALARM


__attribute__((naked)) __attribute__((section (".start_section")))
void startup(void)
{
	__asm__ volatile(" LDR R0,=0x2001C000\n");    /* set stack */
	__asm__ volatile(" MOV SP,R0\n");
	__asm__ volatile(" BL main\n");          /* call main */
	__asm__ volatile(".L1: B .L1\n");        /* never return */
}

// Increment global variable
void volatile increment_tick(void)
{
	Ticks++;
}


uint8_t init_peripheral(void)
{
	//Reset memory
	alarm_is_acked = 1;
	Ticks = 0;
	discover_failure = 0;
	requested_nodeId = 0;
	peripheral.nodeId = 0;
	peripheral.isConnected = 0;
	peripheral.DISCOVER_started = 0;
	if(CURRENT_PERIPHERAL_TYPE == NOISE_MAKER) {
		// Pretend to be a deffective door_alarm
		peripheral.unitType = DOOR_ALARM;
	} else {
		peripheral.unitType = CURRENT_PERIPHERAL_TYPE;
	}


	// Enable USART and CAN communication
	USART_Cmd(USART1, ENABLE);
	DUMP("\nUsart1 enabled.");

#ifdef DYNAMIC_MAC
	// Dynamic MAC generation activated - !!! GENERATION DOES NOT CURRENTLY WORK !!!
	DUMP("\nDYNAMIC MAC\n");
	//init_tim2(increment_tick);
	uint8_t zero[] = {0,0,0,0};
	setPeripheralMAC(zero);
#else
	// Hardcode a manual MAC address for the unit like it would be in real life
	DUMP("\nMANUAL MAC - ");
	uint8_t manual[] = {0,0,0,2};
	setPeripheralMAC(manual);
	Debug_dump_MAC(peripheral.MAC);
	DUMP("\n");
#endif


	can1_init(peripheral_can_receiver);

	// Wait for central unit to confirm peripheral unit connection
	while(!peripheral.isConnected && discover_failure < MAX_DISCOVER_FAILURE);
	return peripheral.isConnected;
}

uint8_t count = 0;

void handler(void)
{
	//DOOR_ALARM_UnlockDoor(0);
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	count++;
}
/*void main(void){
	//DOOR_ALARM_TEST_GPIOInit();
	//DOOR_ALARM_TEST_Diodes();
	//DOOR_ALARM_TEST_LocalAlarm();
	//DOOR_ALARM_TEST_Complete();
	//DOOR_ALARM_CONFIG TEST_CONFIG = {0x3FF,4,4};
	//DOOR_ALARM_Init(&TEST_CONFIG);
	//DOOR_ALARM_Run();
	TIMERS_DeinitTIM(3);
	TIMERS_InitTIM(3, 4200, 2000, handler);
	GPIO_InitGPIO(0b01000, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_NOPULL, 0xFF);
	while(1) {
		GPIOD->ODR = count;
	}
}*/

void main(void)
{
	// Simply wait for the discover to get resolved
	if(init_peripheral()) {
		DUMP("\n\nPeripheral Connection SUCCESS!\n");
	} else {
		DUMP("\n\nPeripheral Connection FAILURE!\n");
	}
	// Try door alarm/motion alarm
	switch(CURRENT_PERIPHERAL_TYPE) {
		case MOTION_SENSOR_ALARM:
			DUMP("MOTIONSSS");
			MOTION_ALARM_init_motion_alarm();
			motion_sensor_TIM();
			while (motion_alarm_sensor.sensor_distance_sensitivity == 0);
			MOTION_ALARM_calibrate_dist();
			MOTION_ALARM_set_dist_sens(motion_alarm_sensor.sensor_distance_sensitivity); 		//sets distance-deviation value
			DUMP("\n\nMOTION ALARM CALIBRATED");
			while(1) {
				MOTION_ALARM_update_dist();
				if (MOTION_ALARM_detect_dist_deviations() /*&& alarm_is_acked*/) {
					DUMP("\nAlarm triggered by distance sensor!");
					if(alarm_is_acked) {
						send_motion_alarm(MOTION); //trigger alarm
					}

				}
				if (MOTION_ALARM_detect_vibration() && alarm_is_acked) {
					DUMP("\nAlarm triggered by vibration sensor!");
					send_motion_alarm(VIBRATION); //trigger alarm
				}
			}
			break;
		case DOOR_ALARM:
			// Put all door alarm code in startup here <<<<
			DOOR_ALARM_Run();
			break;
		case NOISE_MAKER:
			// Test how the system handles a deffective unit
			noise_maker_init();
			break;
	}
}
