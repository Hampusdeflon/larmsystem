#include "door_alarm_test.h"

void DOOR_ALARM_TEST_GPIOInit(void) {
  GPIO_DeInitGPIO(0b1000);
  GPIO_InitGPIO(0b1000, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_NOPULL, 0xFF);
  uint32_t ticks = 0;
  uint8_t counter = 0;
  while (1) {
    if (ticks == 10000000) {

      if (counter == 255) counter = 0;
      counter++;

      ticks = 0;
    }

    GPIOD->ODR = counter;
  }
}

void DOOR_ALARM_TEST_Diodes(void) {
  GPIO_DeInitGPIO(0b1000);
  GPIO_InitGPIO(0b1000, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_NOPULL, 0xFFFF);
  GPIO_InitGPIO(0b1000, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, 0x1249);

  uint32_t ticks = 0;
  uint8_t diode_on = 0;

  while (1) {
    ticks++;
    if (ticks == 10000000) {
      diode_on = !diode_on;
      ticks = 0;

      if (diode_on) {
        GPIOD->ODR = ~0x1249;
      } else {
        GPIOD->ODR = 0x0000;
      }
    }
  }
}

/*
 * Tests the functionality of the set_local_alarm function
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_TEST_LocalAlarm(void) {
	//uint32_t ones = 0x0FFFFFFf;
	//DOOR_ALARM_CONFIG *TEST_CONFIG = (DOOR_ALARM_CONFIG *) &ones;
	DOOR_ALARM_CONFIG TEST_CONFIG = {0x3FF,4,4,1};

	DOOR_ALARM_Init(&TEST_CONFIG);	
	uint32_t ticks = 0;
	uint8_t alarm_on = 0;

	while (1) {
		ticks++;
		if (ticks == 10000000) {
			ticks = 0;
			alarm_on = !alarm_on;
			if (alarm_on) {
					set_local_alarm(0xFFFF);
			} else {
				set_local_alarm(0);
			}
		}
	}
}
/*
 * Tests the functionality of door alarm (switches)
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_TEST_Complete(void) {
  DOOR_ALARM_CONFIG TEST_CONFIG = {0x3FF,4,4,1};

  DOOR_ALARM_Init(&TEST_CONFIG);

  DOOR_ALARM_Run();
}

uint32_t test_timeout_ticks = 1;
uint16_t test_open_doors = 0;
uint32_t test_open_door_ticks[10];
uint32_t test_unlocked_doors_start[10];
uint32_t test_ticks = 0;
uint8_t test_locked = 1;

void test_lock_door(uint16_t set_lock_doors) {
  for (uint8_t i = 0; i < 10; i++) {
    if (set_lock_doors & (1 << i)) {
      test_unlocked_doors_start[i] = test_timeout_ticks;
    } else {
      test_unlocked_doors_start[i] = 0;
    }
  }
}

void test_interrupt(void) {
  TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

  test_timeout_ticks++; // Every time the interrupt is made, the tick counter is incremented

  for (uint8_t i = 0; i < 10; i++) {
    if (test_open_doors & (1 << i)) { // Check whether the door is open
      // Bit i is set in open_doors which means that door i is currently open.
      // The counter in open_door_ticks is incremented to keep track of how long door i have been opened.
      test_open_door_ticks[i]++;
    } else {
      // Bit i is not set and door i is therefore closed.
      // The counter for door i is therefore reset to 0.
      test_open_door_ticks[i] = 0;
    }
  }

  test_ticks++;

  if (test_ticks == 30) {
    test_ticks = 0;
    test_locked = !test_locked;

    if (test_locked) {
      // Unlock doors
      test_lock_door(0);
    } else {
      // Lock doors
      test_lock_door(0x3FF);
    }
  }
}

void test_set_local_alarm(uint16_t set_alarm_doors) {
  for (uint8_t i = 0; i < 10; i++) {
    if (set_alarm_doors & (1 << i)) {
      if (i < 5) {
        GPIOD->ODR |= 1 << (3 * i + 2);
      } else {
        GPIOE->ODR |= 1 << (3 * i - 13);
      }
    } else {
      if (i < 5) {
        GPIOD->ODR &= ~(1 << (3 * i + 2));
      } else {
        GPIOE->ODR &= ~(1 << (3 * i - 13));
      }
    }
  }
}

/*
 * Tests the functionality of unlocking doors in conjunction with the local alarm.
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_TEST_UnlockDoor(void) {
  uint32_t test_open_door_duration = 10;

  GPIO_DeInitGPIO(0b1000);
  GPIO_InitGPIO(0b01000, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_NOPULL, 0b001001001001001);
  GPIO_InitGPIO(0b01000, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_DOWN, 0b110110110110110);

  TIMERS_InitTIM(2, 4200, 2000, test_interrupt);

  while (1337) {
    if ((test_open_doors = poll_pins())) {
      uint16_t local_alarm_doors = 0;

      for (uint8_t i = 0; i < 10; i++) {
        // If the door is open but not unlocked or have been open longer than allowed (open_door_duration)
        if ((test_open_doors & (1 << i) && !test_unlocked_doors_start[i]) || test_open_door_ticks[i] > test_open_door_duration) {
          local_alarm_doors |= 1 << i; // Set the bit corresponding to the open door to 1

          // If the door have been unlocked longer than allowed
          if (test_unlocked_doors_start[i] < test_timeout_ticks - test_open_door_duration) {
            test_unlocked_doors_start[i] = 0; // Reset unlocked tick stamp
          }
        }
      }

      test_set_local_alarm(local_alarm_doors); // Enable/disable local alarm
    }
  }
}
