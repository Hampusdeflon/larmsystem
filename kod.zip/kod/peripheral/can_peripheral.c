#include "can_peripheral.h"
#include "can.h"
#include "door_alarm.h"
#include "random.h"
#include "MAC.h"
#include "can_door_alarm.h"
#include "motion_alarm.h"
#include "peripheral.h"



void peripheral_can_send(uint8_t *msg, uint8_t msg_size, uint8_t is_alarm, uint8_t is_ping)
{
	uint8_t alarm_msg_id = (is_alarm << 5) || (is_ping << 3);
	can_send_msg(msg, alarm_msg_id, peripheral.nodeId, msg_size);
}

/* Discover a nodeId from the centralunit with a broadcast message
 * This starts the nodeId setup protocol with total of 4 exchanges of messages
 * Type 0 message
 * @author Martin Engström, Houmam*/
void DISCOVER()
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_PERIPHERAL;
	msg.msgId = 0;
	msg.nodeId = 31;
	msg.length = 0;
	can_send(&msg);
	DUMP("\nDISCOVER SENT");
}

/* Request a nodeId from the centralunit
 * Type 2 message
 * @param nodeId Received nodeId from OFFER type message
 * @param unitType motionAlarm or doorAlarm
 * @param MAC 4 bytes long MAC address
 * @author Martin Engström, Houmam
 * */
void REQUEST(uint8_t nodeId, enum PERIPHERAL_TYPE unitType, uint8_t* MAC)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_PERIPHERAL;
	msg.msgId = 2;
	msg.nodeId = nodeId;
	msg.length = 5;
	// Store MAC address in buff
	for (int i = 0; i < 4; i++) {
		msg.buff[i] = MAC[i];
	}
	msg.buff[4] = unitType;
	can_send(&msg);
	DUMP("\nREQUEST SENT\n");
}

/* Sends a ping message to central unit
 * Type 6 messages
 * @param ping_msg The response code from the received ping thats being answered
 * @author Adam Magnusson, Martin Engström
 * */
void PING(uint8_t secret)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_PERIPHERAL;
	msg.msgId = 6;
	msg.nodeId = peripheral.nodeId;
	msg.length = 5;
	copyArray(msg.buff,peripheral.MAC,4);
	msg.buff[4] = secret;
	can_send(&msg);
	DUMP("\nPING sent to central");
}
/*
 * Send door alarm to central unit
 * Type 5 messages
 * @param door_number The index of the door (alarm) in NBCD encoding
 * @author Leopold Wigbratt & Houmam Kadamani
 */
void peripheral_send_door_alarm(){
	CANMsg msg;
	msg.alarm = ALARM_TRIGGERED;
	msg.dir = MSG_DIR_FROM_PERIPHERAL;
	msg.msgId = 5;
	msg.nodeId = peripheral.nodeId;
	msg.length = 4;
	msg.buff[0] =  *((uint32_t*)peripheral.MAC);
	alarm_is_acked = 0;

	can_send(&msg);
}

/*
 * IRQ handler for can.
 * This function is called when a message is received.
 * The peripheral unit decides what to do with it depending on the message type.
 *
 * */
void peripheral_can_receiver()
{
	CANMsg msg;
	can_receive(&msg);
	/* Check if message received is from central unit and is correctly formatted.
	 * Ignore all other messages.*/
	uint8_t msgValidity = verify_CANMsg_validity(&msg);
	if(msg.dir == MSG_DIR_FROM_PERIPHERAL || !msgValidity) {
		return;
	}

	// Message type received is:
	switch(msg.msgId) {
		case 1:
			/* Received: OFFER on nodeId from centralunit
			 * Response: If node_id is set ignore, else respond with REQUEST*/
			;
#ifdef DYNAMIC_MAC
			uint8_t zero[] = {0,0,0,0};
			if(compareArrays(peripheral.MAC, zero, 4)) {
				//Set MAC
				DUMP("\nSetting MAC\n");
				uint32_storeMAC(peripheral.MAC,Ticks);
				Debug_dump_MAC(peripheral.MAC);
				DUMP("\n");
			}
#endif
			if(peripheral.nodeId > 0 && peripheral.nodeId < 31) {
				DUMP("OFFER received, nodeId already set, IGNORE");
				return;
			}
			DUMP("\nOFFER RECEIVED\n");
			peripheral.nodeId = msg.buff[0];
			REQUEST(msg.buff[0], peripheral.unitType, peripheral.MAC);
			break;
		case 3:
			/* Received: ACK or NAK for REQUEST
			 * Response: None*/
			;
			if(peripheral.isConnected) return;
			// Collect MAC from first 4B of 5B message
			uint8_t rMAC[4];
			collectMAC(rMAC, &msg, 3);
			// Verify that peripherals MAC is the same as from the message
			if(!compareArrays(rMAC, peripheral.MAC, 4)) {
				DUMP("\nACKorNAK RECEIVED, wrong MAC, centralunit is talking to someone else\n");
				return;
			}

			uint8_t ACK = (!msg.buff[4]);
			if(ACK) {
				DUMP("ACK RECEIVED\n");
				// Establish connection from peripheral to central unit
				peripheral.isConnected = 1;
				DUMP("\n Peripheral connected with nodeId: ");
				DUMP_int(peripheral.nodeId);
			} else {
				// Attempt to send discover again or give up
				peripheral.nodeId = 0;
				DUMP("\nNAK RECEIVED\n");
				discover_failure++;
				if(discover_failure < MAX_DISCOVER_FAILURE) {
					DISCOVER();
				} else {
					DUMP("MAX_DISCOVER_FAILURE reached");
				}
			}
			break;
		case 6:
			/* Received: PING with code in buff
			 * Response: PING responding back with same code*/
			if(compareArrays(peripheral.MAC, msg.buff, 4)) {
				PING(msg.buff[4]);
			}
			break;
		case 7:
			/*Recieved: motion sensor sensitivity
			 *Response: None*/
			if(peripheral.unitType == MOTION_SENSOR_ALARM){
				MOTION_ALARM_set_dist_sens(msg.buff[0]);
			}
			break;
		case 8:
			alarm_is_acked = 1;
			if(peripheral.unitType == DOOR_ALARM){
				remove_central_alarm();
			}
			break;
		case 9:
			/*Recieved: READY - central is ready for discover messages
			 *Response: if DISCOVER protocol not already started send DISCOVER*/

			if(peripheral.DISCOVER_started) return;
			DUMP("\nDISCOVERING NODEID");
			discover_failure = 0;
			peripheral.DISCOVER_started = 1;
			DISCOVER();
			break;
		case 10:
			//DOOR_ALARM_Init(msg.buff);
			if(peripheral.unitType == DOOR_ALARM){
				recieved_to_doors(msg.buff);
			}
			
			break;
	}
}
void recieved_to_doors(uint8_t msgBuff[])
{
	DOOR_ALARM_CONFIG config;
	
	config.enable_doors = msgBuff[0];
	config.enable_doors |= msgBuff[1] << 8;
	config.open_door_s = msgBuff[2];
	config.local_alarm_s = msgBuff[3];
	DUMP("\n enable_doors");
	DUMP_int(config.enable_doors);
	DUMP("\n open_door_s");
	DUMP_int(config.open_door_s);
	DUMP("\n local_alarm_s");
	DUMP_int(config.local_alarm_s);
	
	DOOR_ALARM_Init(&config);
	//CAN_DOOR_ALARM_MESSAGE *door_alarm_msg = (CAN_DOOR_ALARM_MESSAGE*)msgBuff;
	//DUMP("\n");
	//DUMP_int(door_alarm_msg->message_type);

	/*switch (door_alarm_msg->message_type) {
		case CONFIGURATION:
			for(int i = 0; i < 5; i++){
				DUMP("\n");
				DUMP_int(msgBuff[i]);
			}
			DOOR_ALARM_Init(&(door_alarm_msg->config));
			break;
		case LOCK_DOOR:
			DOOR_ALARM_LockDoor(door_alarm_msg->door_index);
			break;
		case UNLOCK_DOOR:
			DOOR_ALARM_UnlockDoor(door_alarm_msg->door_index);
			break;
		case ENABLE_DOOR:
			DOOR_ALARM_EnableDoor(door_alarm_msg->door_index);
			break;
		case DISABLE_DOOR:
			DOOR_ALARM_DisableDoor(door_alarm_msg->door_index);
			break;
	}*/
}



/* Sends motion sensor alarm to central
 * Type 4 messages
 * @param vib_or_motion Alarm type, Motion sensor:0 | Vibration sensor:1.
 * @author Hampus and Adam and Houmam*/
void send_motion_alarm(enum MOTION_ALARM_TYPE vib_or_motion)
{
	DUMP("Skickar till CU");
	alarm_is_acked = 0;

	CANMsg msg;
	msg.alarm = ALARM_TRIGGERED;
	msg.dir = MSG_DIR_FROM_PERIPHERAL;
	msg.msgId = 4;
	msg.nodeId = peripheral.nodeId;
	msg.length = 1;
	msg.buff[0] = vib_or_motion;

	can_send(&msg);
}


