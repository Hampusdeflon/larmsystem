#include <stdint.h>
#include <stdio.h>
#include "gpio.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_tim.h"
#include "stm32f4xx_adc.h"
#include "usart.h"
#include "timers.h"
#include "can.h"
#include "misc.h" /* High level functions for NVIC and SysTick (add-on to CMSIS functions) */

typedef struct {
	//uint32_t mac_adress;
	//uint8_t node_id;
	uint16_t sensor_distance;
	uint16_t sensor_calibrate_distance;
	uint16_t sensor_distance_sensitivity;	//Känsligheten avger hur mycket mätvärdet får avvika från refernsvärdet innan larmet utlöses
	//uint8_t alarm_triggered;
} MOTION_SENSOR_CAN_MSG, *PMOTION_SENSOR_CAN_MSG;

MOTION_SENSOR_CAN_MSG motion_alarm_sensor;



void MOTION_ALARM_init_motion_alarm(void);

void MOTION_ALARM_motion_sensor_TIM(void);

void MOTION_ALARM_calibrate_dist(void);

void MOTION_ALARM_set_dist_sens(uint8_t sensativity);

void MOTION_ALARM_update_dist(void);

uint8_t MOTION_ALARM_detect_dist_deviations(void);

uint8_t MOTION_ALARM_detect_vibration(void);