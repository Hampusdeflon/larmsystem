/*@file    motion_alarm.c
* @author  Hampus de Flon and Adam
* @version V1
* @date    13-October-2021
* @brief   This file provides functions to manage the motion alarm peripheral, which consists of a vibration and motion sensor.
* The vibration sensor sensitivity can be configured in startup.c (by function MOTION_ALARM_set_dist_sens())
* both the vibration and distance sensors functions are coded to return 1 when the alarm should be triggered
*/

#include "motion_alarm.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include <misc.h>

#define trigger_pin GPIO_Pin_0
#define echo_pin	GPIO_Pin_1
#define digital_pin GPIO_Pin_0

/*Initiates Tim with 1 micro sec as update interval
 *@author Hampus de Flon*/
void motion_sensor_TIM(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	TIM_TimeBaseInitTypeDef timer_init_structure;

	timer_init_structure.TIM_Prescaler = (84-1);
	timer_init_structure.TIM_Period = (0xFFFFFFFF);
	timer_init_structure.TIM_CounterMode = TIM_CounterMode_Up;
	timer_init_structure.TIM_ClockDivision = TIM_CKD_DIV1;

	TIM_TimeBaseInit(TIM2, &timer_init_structure);
	TIM_Cmd(TIM2, ENABLE);
	TIM_ITConfig(TIM2,TIM_IT_Update, ENABLE);
}


void EXTI0_handler(void){
	if (EXTI_Line0 != RESET){
		send_motion_alarm(VIBRATION);
		EXTI_ClearITPendingBit(EXTI_Line0);
		DUMP("vibrationslarm");
	}
}

/*Configures GPIO pins for ultrasonic sensor (PE0,PE1)    and vibrationsensor (PE2)
 *@author Hampus de Flon and Adam*/
void MOTION_ALARM_init_motion_alarm(void)
{
	GPIO_InitTypeDef GPIO_init_structure;
	GPIO_StructInit(&GPIO_init_structure);
	//EXTI_InitTypeDef EXTI_InitStruct;
	//NVIC_InitTypeDef NVIC_InitStruct;
	GPIO_DeInit(GPIOE); //BARA E ELLER D

	//RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	

	//Connect Ultrasonic Ranging Module to pins : PE0, PE1
	//Trigger - output
	GPIO_init_structure.GPIO_Pin   = GPIO_Pin_0;
	GPIO_init_structure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_init_structure.GPIO_OType = GPIO_OType_PP;
	GPIO_init_structure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_init_structure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE, &GPIO_init_structure);
	//Echo - input
	GPIO_init_structure.GPIO_Pin   = GPIO_Pin_1;
	GPIO_init_structure.GPIO_Mode  = GPIO_Mode_IN;
	GPIO_init_structure.GPIO_OType = GPIO_OType_PP;
	GPIO_init_structure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_init_structure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE, &GPIO_init_structure);


	//Connect Vibration Sensor Module to pin : PD0
	/*GPIO_init_structure.GPIO_Pin   = GPIO_Pin_0;
	GPIO_init_structure.GPIO_Mode  = GPIO_Mode_IN;
	GPIO_init_structure.GPIO_OType = GPIO_OType_PP;							
	GPIO_init_structure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_init_structure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOD, &GPIO_init_structure);*/
	
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
	//SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOD, EXTI_PinSource0);
	
	/*EXTI_InitStruct.EXTI_Line = EXTI_Line0;
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_InitStruct);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitStruct.NVIC_IRQChannel = EXTI0_IRQn;
	
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x00;
	
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStruct);
	
	*((int *) 0x2001C058) = EXTI0_handler;*/
}

/*Returns the distance measured by the ultra sonic sensor in cm
 *@author Hampus de Flon*/
uint16_t get_dist(void)
{
	uint32_t max_distance = (400 * 58);			// 400cm * 58 = 23200 pulse timed

	GPIO_WriteBit(GPIOE,trigger_pin, Bit_RESET);//make sure trigger pin is deactivated
	TIM_SetCounter(TIM2,0);
	TIM_Cmd(TIM2,ENABLE);
	while(TIM_GetCounter(TIM2) < 2) {} 			//delay_micro(2);
	TIM_Cmd(TIM2,DISABLE);

	GPIO_WriteBit(GPIOE,trigger_pin, Bit_SET);	//activate trigger pin for 10 micro seconds - send pulse for 10 μs
	TIM_SetCounter(TIM2,0);
	TIM_Cmd(TIM2,ENABLE);
	while(TIM_GetCounter(TIM2) < 10);			//delay 10 micro sec
	TIM_Cmd(TIM2,DISABLE);
	GPIO_WriteBit(GPIOE,trigger_pin, Bit_RESET);

	while (GPIO_ReadInputDataBit(GPIOE, echo_pin) == 0) {}	//wait for echo pulse to receive
	TIM_SetCounter(TIM2,0);
	TIM_Cmd(TIM2,ENABLE);
	while (GPIO_ReadInputDataBit(GPIOE, echo_pin) == 1) {}	//make sure echo pulse has ended
	long pulse_time = TIM_GetCounter(TIM2);
	TIM_Cmd(TIM2,DISABLE);

	if (pulse_time > max_distance) {				//range inside hardware capacity?
		pulse_time = max_distance;
		DUMP("Nothing in range");
	}

	uint16_t distance_cm = (pulse_time / 58);		//convert pulse time to cm

	DUMP("\nDistance in cm: ");
	DUMP_int(distance_cm);


	

	return distance_cm;
}

/*Updates struct with the first measured distance
 *@author Hampus de Flon*/
void MOTION_ALARM_calibrate_dist(void)
{
	uint16_t dist_temp = get_dist();

	motion_alarm_sensor.sensor_calibrate_distance = dist_temp;
	DUMP("\nmotion sensor calibrated! value:");
	DUMP_int(dist_temp);
}

/*Updates struct with the parameter.
 *@param sensitivity is the standard deviation to accept for the ultrasonic sensor.
 *@author Hampus de Flon*/
void MOTION_ALARM_set_dist_sens(uint8_t sensitivity)
{
	motion_alarm_sensor.sensor_distance_sensitivity = sensitivity;
	DUMP("\nMotion sensor sensitivity: ");
	DUMP_int(motion_alarm_sensor.sensor_distance_sensitivity);
}

/*Updates struct with the current distance
 *@author Hampus de Flon*/
void MOTION_ALARM_update_dist(void)
{
	motion_alarm_sensor.sensor_distance = get_dist();
}

/*Returns 1 if there is  deviation in distance compared to the calibrated distance
 *@author Hampus de Flon*/
uint8_t MOTION_ALARM_detect_dist_deviations(void)
{
	uint8_t curr_dist  = motion_alarm_sensor.sensor_distance;
	uint8_t calib_dist = motion_alarm_sensor.sensor_calibrate_distance;
	uint8_t margin     = motion_alarm_sensor.sensor_distance_sensitivity;
	if( (curr_dist >= (calib_dist - margin)) && (curr_dist <= (calib_dist + margin)) )
		return 0; // no deviations

	return 1; //deviation

}
/*Returns 1 if vibrations are detected
 *@author Hampus de Flon and Adam Magnusson*/
uint8_t MOTION_ALARM_detect_vibration(void)
{
	//DUMP("\nVibration detected: ");
	//DUMP_int(!GPIO_ReadInputDataBit(GPIOD, digital_pin));
	
	TIM_SetCounter(TIM2,0);
	TIM_Cmd(TIM2,ENABLE);
	while(TIM_GetCounter(TIM2) < 1000000) {
		if (!GPIO_ReadInputDataBit(GPIOD, digital_pin)) { //vibration detection

			return 1;
		}
	} 		//1 sec delay until next measure
	TIM_Cmd(TIM2,DISABLE);

	
    return 0;     //read value from pin PE2, input 1 means no vibration

    
    
	/*
	//read value from pin PE2
	DUMP("\nVibration sensor value ");
	DUMP_int(GPIO_ReadInputDataBit(GPIOE, digital_pin));
	if (GPIO_ReadInputDataBit(GPIOE, digital_pin)) { //input 1 means no vibration
		return 0; // no alarm
	}

	return 1; // vibration detected, sound the alarm*/

}
