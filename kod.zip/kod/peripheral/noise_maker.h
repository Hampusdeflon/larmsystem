#ifndef NOISE_MAKER_H
#define NOISE_MAKER_H

#include <stdint.h>
#include <stdint.h>
#include <timers.h>
#include <can.h>
#include <debug.h>
#include "random.h"

void noise_maker_init( void );

#endif