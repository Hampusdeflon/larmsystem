#include "door_alarm.h"

// The frequency of how frequent the timeout_interrupt_handler function is called.
#define TICK_FREQUENCY 10
// Comment out to disable verbose USART output
#define DEBUG_DOOR_ALARM

// The doors with alarm enabled.
// Bit 0-9 correspond to the 10 door alarms that can be enabled.
// If bit i is set, door i is enabled (e.g. the least significant bit represents door 0).
uint16_t enabled_doors = 0;

// The doors currently opened (with alarm enabled).
// Bit 0-9 correspond to the 10 door alarms that can be enabled.
// If bit i is set, door i is currently opened.
uint16_t open_doors = 0;

// The duration a door can be opened after being unlocked, until the alarm should be enabled locally.
// This variable is in terms of ticks (the time is therefore depending on TICK_FREQUENCY).
// It is set by the open_door_s (in seconds) in the DOOR_ALARM_CONFIG struct passed to DOOR_ALARM_Init.
uint32_t open_door_duration = 0;

// The duration a local alarm can be active until the central unit has to be notified.
// This variable is in terms of ticks (the time is therefore depending on TICK_FREQUENCY).
// It is set by the local_alarm_s (in seconds) in the DOOR_ALARM_CONFIG struct passed to DOOR_ALARM_Init.
uint32_t local_alarm_duration = 0;

// A counter that is incremented on every call to timeout_interrupt_handler.
uint32_t timeout_ticks = 1;

// An array of time stamps representing the state of timeout_ticks when door i at index i was opened.
uint32_t open_doors_start[10];

// An array of time stamps representing the state of timeout_ticks when door i at index i was unlocked.
uint32_t unlocked_doors_start[10];

uint32_t open_door_ticks[10];

// The door alarms that currently have activated central alarm.
// Each bit represents a door.
uint16_t currently_activated_central_alarms = 0;

uint16_t send_central_alarm;

/*
 * The IRQ handler function for the SysTick_Timebase_Init time keeping function.
 * @author Leopold Wigbratt
 */
void timeout_interrupt_handler(void) {
  timeout_ticks++; // Every time the interrupt is made, the tick counter is incremented

  for (uint8_t i = 0; i < 10; i++) {
    if (open_doors & (1 << i) && !unlocked_doors_start[i]) { // Check whether the door is open
      if (open_doors_start[i] == 0xFFFFFFFF) {
        open_doors_start[i] = timeout_ticks;
      }
    } else {
      open_doors_start[i] = 0xFFFFFFFF;
    }
  }

  // Acknowledge the interrupt
  TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
}

/*
 * Initialize door alarm on the peripheral unit
 * @param config The configuration struct for the door alarm (see door_alarm.h)
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_Init(DOOR_ALARM_CONFIG *config) {
  DUMP("\nInitializing door alarm...\n");

	uint16_t gpiod_output_pins = 0; // Pins that should be set to output on GPIOD
	uint16_t gpiod_input_pins = 0; // Pins that should be set to input on GPIOD
	uint16_t gpioe_output_pins = 0; // Pins that should be set to output on GPIOE
	uint16_t gpioe_input_pins = 0; // Pins that should be set to input on GPIOE

	//node_ids_start = config->node_ids_start;

	enabled_doors = config->enable_doors;

	// open_door_duration is the amount of ticks that corresponds to seconds defined in open_door_s
	open_door_duration = config->open_door_s * TICK_FREQUENCY;

	// local_alarm_duration is the amount of ticks that corresponds to seconds defined in local_alarm_s
	local_alarm_duration = config->local_alarm_s * TICK_FREQUENCY;

	for (uint8_t i = 0; i < 10; i++) {
		if (enabled_doors & (1 << i)) {
			if (i < 5) { // The first five door alarms are connected to GPIOD (bits 0-4 in enabled_doors)
				gpiod_input_pins |= 0b001 << (i * 3); // Initialize one pin for input (alarm sensor)
				gpiod_output_pins |= 0b110 << (i * 3); // Initialize two pins for output (green and red diodes respectively)
			} else { // The last five door alarms are connected to GPIOE (bits 5-9 in enabled_doors)
				gpioe_input_pins |= 0b001 << (3 * i - 15); // Initialize one pin for input (alarm sensor)
				gpioe_output_pins |= 0b110 << (3 * i - 15); // Initialize two pins for output (green and red diodes respectively)
			}
		}
	}

	// Deinitialize GPIOD and GPIOE
	GPIO_DeInitGPIO(0b11000);
	// Initialize the pins that should be used for output on GPIOD
	GPIO_InitGPIO(0b01000, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_NOPULL, gpiod_output_pins);
	// Initialize the pins that should be used for input on GPIOD
	GPIO_InitGPIO(0b01000, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, gpiod_input_pins);
	// Initialize the pins that should be used for output on GPIOE
	GPIO_InitGPIO(0b10000, GPIO_Mode_OUT, GPIO_OType_PP, GPIO_PuPd_NOPULL, gpioe_output_pins);
	// Initialize the pins that should be used for input on GPIOE
	GPIO_InitGPIO(0b10000, GPIO_Mode_IN, GPIO_OType_PP, GPIO_PuPd_UP, gpioe_input_pins);

	// Make sure that each element in open_door_ticks is initialized to 0.
	for (uint8_t i = 0; i < 10; i++) {
		open_doors_start[i] = 0xFFFFFFFF;
		unlocked_doors_start[i] = 0;
	}

  DUMP("Initialization completed.\n");
  DUMP("Enabled door alarms: \n");
  DUMP_int(enabled_doors);
  DUMP("\n");
}

/*
 * Check whether or not the input pins of enabled doors are opened or not.
 * @returns The doors currently opened.
 * @author Leopold Wigbratt
 */
uint16_t poll_pins(void) {
	// Temp variable where the 10 lower bits represents an open door. Bit 0 represents door 0
	uint16_t open_doors_temp = 0;

	for (uint8_t i = 0; i < 5; i++) {
		// Mask bit i (multiples of 3) from IDR and then move it to the position of the corresponding door in open_doors_temp
		// Every third bit in IDR is an input bit, (1 << i * 3) gives the right position in IDR
		// The masked bit must then be placed in the right position in open_doors_temp
		// >> (i * 2) gives the right position in open_doors_temp for the first five doors (those with pins on GPIOD)
		open_doors_temp |= (GPIOD->IDR & (1 << i * 3)) >> (i * 2);
		// (>> (i * 2)) << 5 gives the right position in open_doors_temp for the last five doors (those with pins on GPIOE)
		// The bits are left shifted 5 places as the first door on GPIOE (door 5) is bit 5 in open_doors_temp
		open_doors_temp |= ((GPIOE->IDR & (1 << i * 3)) >> (i * 2)) << 5;
	}

	return open_doors_temp & enabled_doors; // Ensure that only the state of enabled doors are returned
}

/*
 * Enable one door alarm
 * @param door_index The door alarm to be enabled
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_EnableDoor(uint8_t door_index) {
	enabled_doors |= 1 << door_index;
	if (door_index < 5) {
		// The first five doors use pins on GPIOD.
		// Each door have three pins, of which the second is used for the diode that is enabled when
		// the alarm is disabled.
		// When the alarm is enabled (as in this case) the bit for the diode should be set to 0.
		// 1 << (3 * door_index + 1) moves a bit to the position that corresponds to the diode for the door door_index in ODR.
		// The bit for the diode is always the second bit in a set of three (three bits for every door).
		// As the bit in question should be cleared, the whole integer is inverted so that all bits are set, with
		// the exception of the diode bit, that should be cleared.
		// The bit can then be cleared in ODR with a bitwise AND-operation.
		GPIOD->ODR &= ~(1 << (3 * door_index + 1));
	} else {
		// The last five doors use pins on GPIOE.
		// The variable door_index (representing door door_index) must be subtracted by five as doors that use pins on GPIOE
		// use the same location as door (door_index - 5) on GPIOD.
		// (3 * door_index - 14) is a shortened form of (3 * (door_index - 5) + 1).
		GPIOE->ODR &= ~(1 << (3 * door_index - 14));
	}
}

/*
 * Disable one door alarm
 * @param door_index The door alarm to be disabled
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_DisableDoor(uint8_t door_index) {
	enabled_doors &= ~(1 << door_index);

	// A disabled door does not need its open_door_ticks counter so its cleared for future use
	open_door_ticks[door_index] = 0;

	if (door_index < 5) {
		// The first five doors use pins on GPIOD.
		// Each door have three pins, of which the second is used for the diode that is enabled when
		// the alarm is disabled.
		// 1 << (3 * door_index + 1) ensures that the bit that is set on ODR is the second in a set of bits that is a multiple of three.
		GPIOD->ODR |= 1 << (3 * door_index + 1);
	} else {
		// The last five doors use pins on GPIOE.
		// The variable door_index (representing door door_index) must be subtracted by five as doors that use pins on GPIOE
		// use the same location as door (door_index - 5) on GPIOD.
		// (3 * door_index - 14) is a shortened form of (3 * (door_index - 5) + 1).
		GPIOE->ODR |= 1 << (3 * door_index - 14);
	}
}

/*
 * Lock one door
 * @param The door to be locked
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_LockDoor(uint8_t door_index) {
	unlocked_doors_start[door_index] = 0;
}

/*
 * Unlock one door
 * @param The door to be unlocked
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_UnlockDoor(uint8_t door_index) {
	unlocked_doors_start[door_index] = timeout_ticks;
}

/*
 * Notify that the central alarm has been deactivated
 * @param door_index The door of the alarm that has been deactivated
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_CentralAlarmDisabled(uint8_t door_index) {
  currently_activated_central_alarms &= ~(1 << door_index);
}

// Keeps track of the argument passed to the last set_alarm_doors call
uint16_t last_set_local_alarm_doors = 0;

/*
 * Enables or disable the local alarm for the specified doors.
 * @param set_local_alarm_doors The doors for which the local alarm should be enabled.
 * @author Leopold Wigbratt
 */
void set_local_alarm(uint16_t set_local_alarm_doors) {
  // Quit execution of the function if the parameter is equal to the last call.
  if (set_local_alarm_doors == last_set_local_alarm_doors) return;

  #ifdef DEBUG_DOOR_ALARM
  if(!set_local_alarm_doors){
	  DUMP("\nLocal alarm deactivated");
  }else{
	  DUMP("\nLocal alarm activated");
  }
  #endif

	for (uint8_t i = 0; i < 10; i++) {
		if (set_local_alarm_doors & (1 << i)) {
			// Bit i is set in set_alarm_doors which means that the local alarm for door i should be enabled.
			if (i < 5) {
				// The first five doors use pins on GPIOD.
				// Each door have three pins, of which the third is used for the diode that is enabled when
				// the local alarm is active.
				// 1 << (3 * i + 2) ensures that the bit that is set on ODR is the third in a set of bits that is a multiple of three.
				GPIOD->ODR |= 1 << (3 * i + 2);
			} else {
				// The last five doors use pins on GPIOE.
				// The variable i (representing door i) must be subtracted by five as doors that use pins on GPIOE
				// use the same location as door (i - 5) on GPIOD.
				// (3 * i - 13) is a shortened form of (3 * (i - 5) + 2).
				GPIOE->ODR |= 1 << (3 * i - 13);
			}
		} else {
			// Bit i is not set in set_alarm_doors which means that the local alarm for door i should be disabled.
			if (i < 5) {
				// The first five doors use pins on GPIOD.
				// Each door have three pins, of which the third is used for the diode that is enabled when
				// the local alarm is active.
				// When the local alarm is disabled (as in this case) the bit for the diode should be set to 0.
				// 1 << (3 * i + 2) moves a bit to the position that corresponds to the diode for the door i in ODR.
				// The bit for the diode is always the third bit in a set of three (three bits for every door).
				// As the bit in question should be cleared, the whole integer is inverted so that all bits are set, with
				// the exception of the diode bit, that should be cleared.
				// The bit can then be cleared in ODR with a bitwise AND-operation.
				GPIOD->ODR &= ~(1 << (3 * i + 2));
			} else {
				// The last five doors use pins on GPIOE.
				// The variable i (representing door i) must be subtracted by five as doors that use pins on GPIOE
				// use the same location as door (i - 5) on GPIOD.
				// (3 * i - 13) is a shortened form of (3 * (i - 5) + 2).
				GPIOE->ODR &= ~(1 << (3 * i - 13));
			}
		}
	}

  last_set_local_alarm_doors = set_local_alarm_doors;
}

/*
 * Enables the central alarm for the specified doors.
 * @param doors A 1 signifies that the central unit should enable the alarm, a 0 signifies it being disabled.
 * @author Leopold Wigbratt, Houmam
 */
void set_central_alarm(uint16_t send_central_alarm) {
  /*if (!set_central_alarm_doors) return;

  if (set_central_alarm_doors == currently_activated_central_alarms) return;

	for (uint8_t i = 0; i < 10; i++) {
		if (set_central_alarm_doors & (1 << i) && !(currently_activated_central_alarms & (1 << i))) {
			peripheral_send_door_alarm(i + 1);

      #ifdef DEBUG_DOOR_ALARM
        DUMP("Central alarm activated for door: ");
        DUMP_int(set_central_alarm_doors);
        DUMP("\n");
      #endif
		}
	}

  currently_activated_central_alarms |= set_central_alarm_doors;
   */
   if(alarm_is_acked && send_central_alarm){
	   peripheral_send_door_alarm();
   }
}
void remove_central_alarm(void){
	send_central_alarm = 0;
}

/*
 * The main function of the door alarm functionality
 * @author Leopold Wigbratt
 */
void DOOR_ALARM_Run(void) {
	// Initialize a TIM2 interrupt every 100 ms with an interrupt handler.
	TIMERS_InitTIM(2, 4200, 2000, timeout_interrupt_handler);

	DUMP("\nDoor alarm started.\n");
	

	while (1337) {
	  // Poll input GPIO pins and check which doors are open
		if ((open_doors = poll_pins())) {
			uint16_t local_alarm_doors = 0;
			send_central_alarm = 0;

      for (uint8_t i = 0; i < 10; i++) {
        // If the door have been unlocked longer than allowed (open_door_duration)
        if (unlocked_doors_start[i] &&
        unlocked_doors_start[i] < timeout_ticks - open_door_duration &&
        timeout_ticks > open_door_duration) {
          unlocked_doors_start[i] = 0; // Reset unlocked tick stamp, "locking" door
        }

        if (open_doors & (1 << i) && !unlocked_doors_start[i]) { // If the door is open and not unlocked
          local_alarm_doors |= 1 << i; // Set the bit corresponding to the open door to 1

          // If the door have been opened longer than allowed (local_alarm_duration)
          if (open_doors_start[i] < timeout_ticks - local_alarm_duration && timeout_ticks > local_alarm_duration) {
            send_central_alarm = 1; 
          }
        }
      }

			set_local_alarm(local_alarm_doors); // Enable/disable local alarm
      set_central_alarm(send_central_alarm); // Enable/disable central alarm
		} else {
		  set_local_alarm(0);
		}
	}
}
