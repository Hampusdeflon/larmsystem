#include "delay.h"
#include <stdint.h>

/*Clock - 168MHz, interrupting delay*/
void Delay(uint32_t nTime)
{
	//nTime in milliseconds
	nTime = 168000 * nTime;
	while(nTime != 0) {
		nTime--;
	}
}
