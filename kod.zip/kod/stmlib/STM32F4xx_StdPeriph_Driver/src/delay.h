#include <stdint.h>

void Delay(uint32_t);
