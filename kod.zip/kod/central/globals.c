#include <nodes.h>
#include <central.h>
// The current amount of nodes connected to the central unit
uint16_t nodeAmount = 0;
// The start of the connected nodes list
NODE* firstNode = 0;
// The end of the connected nodes list
NODE* lastNode = 0;
// Temporary
uint32_t Ticks = 0;
// All available nodes for central unit
NODE NODES[30];
Central_u conf;
