#include <stdint.h>
#include "can.h"
#include "nodes.h"
#include "usart.h"
#include "door_alarm.h"

#define CENTRAL_NODE_ID (0b00000)
void central_can_receiver();
void READY(void);
void PING_ALL(void);
