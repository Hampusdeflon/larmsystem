#include <stdint.h>
#include "can.h"
#include "usart.h"

typedef struct {
	enum PERIPHERAL_TYPE node_type;
	uint8_t MAC[4];
	uint8_t nodeId;
	uint8_t PINGED; // True or false
	uint8_t SECRET; // A code
	uint8_t alarm_triggered;
	uint8_t alarm_on;
} NODE;

// The current amount of nodes connected to the central unit
extern uint16_t nodeAmount;
// A list of all nodes available for the central unit
extern NODE NODES[];
// Add node to list of available nodes if possible
uint8_t addNode(enum PERIPHERAL_TYPE node_type, uint8_t MAC[], uint8_t nodeId);
