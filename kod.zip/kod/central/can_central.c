#include "can_central.h"
#include "alarm.h"
#include "MAC.h"

/* Send a ready-signal to peripherals to signify that the centralunit is waiting for discover messages
 * Type 9 messages
 * @author Martin Engström
 * */
void READY(void)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.msgId = 9;
	msg.nodeId = CENTRAL_NODE_ID;
	msg.length = 0;
	can_send(&msg);
	DUMP("\nSending READY...");
}

/* Send a response to nodeId request messages.
 * If a nodeId could be assigned it sends the MAC address and bit 8 in byte 0 to 0 in data field of message.
 * Otherwise its set to 1.
 * Type 3 messages
 * @param node A datatype of a node containing MAC
 * @param assigned True or false
 * @author Martin Engström, Houmam
 * */
void ACK_or_NAK(uint8_t MAC[], uint8_t assigned)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.msgId = 3; // Type 3
	msg.nodeId = CENTRAL_NODE_ID;
	msg.length = 5;

	for(int i = 0; i < 4; i++) {
		// Copy MAC to byte [0,3] of message
		msg.buff[i] = MAC[i];
	}

	if(!assigned) {
		// nodeId could not be assigned, set NAK flag
		msg.buff[4] = 1;
		DUMP("\nSending NAK");
	} else {
		msg.buff[4] = 0;
		DUMP("\nSending ACK");
	}

	can_send(&msg);
}

/* Sends a response to Discover messages
 * with a free nodeId in data.
 * Type 1 messages
 * @param nodeId A free nodeId
 * @author Martin Engström
 * */
void OFFER(uint8_t nodeId)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.msgId = 1; // Type 1
	msg.nodeId = CENTRAL_NODE_ID;
	msg.length = 1;
	msg.buff[0] = nodeId;
	DUMP("\nOFFER sending with nodeid");
	DUMP_int(msg.buff[0]);
	can_send(&msg);
}

/* Sends a ping message to a node with the specified NodeId
 * Type 6 messages
 * @param nodeId the Id of the node to ping
 * @author Adam Magnusson, Martin Engström
 * */
void PING(uint8_t nodeId)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.msgId = 6;
	msg.length = 5;
	msg.nodeId = CENTRAL_NODE_ID;
	// Store a secret in the message
	msg.buff[4] = 0xFF; //kanske skicka ett slumptal som ska skickas tillbaka?
	NODES[nodeId].SECRET = msg.buff[4];
	// Set which node central is pinging
	copyArray(msg.buff, NODES[nodeId].MAC,4);
	can_send(&msg);
}

/* Checks if any node hasn't responded to ping and pings all again
 * @author Martin Engström
 * */
void PING_CHECK(void)
{
	uint8_t should_enable = 0;
	// Check if any node hasn't pinged back
	for(uint8_t i = 1; i <= nodeAmount; i++) {
		if(NODES[i].PINGED) {
			DUMP("\nALARM - PING WAIT TIME EXCEEDED FOR ");
			DUMP_int(i);
			start_alarm();
			should_enable = 1;
		}else{
			/*DUMP("\nPING CHECK CLEARED FOR NODE ");
			DUMP_int(i);
			DUMP("\n");*/
		}
	}
	if (should_enable )
		start_alarm();
	
}

/* Sends ping to all nodes and starts a timer to check if all nodes are pinged
 * This loops once every second
 * @author Martin Engström, Adam Magnusson
 * */
void PING_ALL(void)
{
	PING_CHECK();
	// Ping all nodes
	for (int i = 1; i <= nodeAmount; i++) {
		PING(NODES[i].nodeId);
		NODES[i].PINGED = 1;
	}
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
}

/* A simple alarm for poorly formatted messages
* @author Martin Engström, Houmam
* */
void alarm_noise(uint8_t nodeId)
{
	char invalidMsg[20] = "\nALARM - Noise on the bus! ";
	DUMP(invalidMsg);
	DUMP_int(nodeId);
}

void send_door_msg(DOOR_ALARM_CONFIG *door_alarm_config)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.nodeId = 0;
	msg.msgId = MSG_TYPE_CENTRAL_CONFIGUR_DOOR;

	msg.length = 4;

	msg.buff[0] = door_alarm_config->enable_doors;
	msg.buff[1] = door_alarm_config->enable_doors >> 8;
	msg.buff[2] = door_alarm_config->open_door_s;
	msg.buff[3] = door_alarm_config->local_alarm_s;
	/*for(int i = 0; i < 4; i++){
		DUMP("\n");
		msg.buff[i] = ((uint8_t*) door_alarm_config)[i];
		DUMP_int(msg.buff[i]);

	}*/
	/*msg.buff[0] = door_alarm_msg->message_type;
	msg.length = 5;
	if(door_alarm_msg->message_type == CONFIGURATION) {
		//msg.buff[1] = (uint32_t) door_alarm_msg->config;
		for(int i = 0; i < 4; i++){
			msg.buff[i] = ((uint8_t*) door_alarm_config)[i];
		}
	} else {

		msg.buff[1] = ((uint8_t*) door_alarm_msg)[1];

	}*/

	can_send(&msg);
}
/*Sends sensitivity to motion_sensor peripheral
 * @author Hampus de Flon
 *  */
void send_motion_msg(uint8_t sensitvity)
{
	CANMsg msg;
	msg.alarm = ALARM_PASSIVE;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.msgId = 7;
	msg.nodeId = CENTRAL_NODE_ID;
	msg.length = 1;
	msg.buff[0] = sensitvity;

	can_send(&msg);
}


/*
 * send ack to peripheral on recieving alarm.
 * */
void send_alarm_ack(void)
{
	CANMsg msg;
	msg.alarm = ALARM_TRIGGERED;
	msg.dir = MSG_DIR_FROM_CENTRAL;
	msg.msgId = MSG_TYPE_CENTRAL_ALARM_ACK;
	msg.nodeId = CENTRAL_NODE_ID;
	msg.length = 0;

	DUMP("\nSkickar ACK! :)");
	can_send(&msg);
}

/* IRQ handler for messages received by the central unit.
 * It decides first if the message is valid, if it's invalid the noise alarm is started.
 * If it's valid the message type is decided and the appropriate response is made.
* @author Martin Engström, Houmam, Hampus de Flon
* */
void central_can_receiver()
{

	// Store received message
	CANMsg msg;
	can_receive(&msg);

	// Verify CANMsg format and that msg is coming from a peripheral
	uint8_t msgValidity = verify_CANMsg_validity(&msg);
	if(msg.dir == MSG_DIR_FROM_CENTRAL || !msgValidity) {
		DUMP("\nALARM - Noise on the bus");
		start_alarm();
		return;
	}

	if(msg.alarm == ALARM_TRIGGERED) {
		// Handler for alarm messages
		switch(msg.msgId) {
			case 4:
				/* Received : Motion sensor alarm
				 * Response : None*/
				{
					uint8_t vib_or_motion = msg.buff[0];
					if(vib_or_motion == MOTION) {
						DUMP("\nMOTION ALARM TRIGGERED BY MOTION ALARM");
						start_alarm();
					} else if(vib_or_motion == VIBRATION) {
						DUMP("\nVIBRATION ALARM TRIGGERED BY VIBRATION ALARM");
						start_alarm();
					}
					break;
				}
			case 5:
				/* Received : Door alarm
				 * Response : None*/
				NODES[msg.nodeId].alarm_triggered = 1;
				start_alarm();
				break;
		}
	}

	// Handler for non-alarm messages
	switch(msg.msgId) {
		case 0:
			/* Received : Discover nodeId
			 * Response : Offer availble nodeId*/
			OFFER(nodeAmount + 1);
			break;
		case 2:

			/* Received : Request for nodeId
			 * Response : Add the node and send ACK || Send NAK*/

			// Collect MAC from last 4B of 5B message
			DUMP("\nREQUEST received, sending ACK or NAK");
			uint8_t MAC[4];
			uint8_t stillAvailable;
			collectMAC(MAC, &msg, 3);
			// Check if peripherals MAC is already in use
			if(find_node_by_MAC(MAC)) {
				DUMP("This MAC address is already in use!");
				stillAvailable = 0;
			}else{
				// Try to add node
				uint8_t stillAvailable = (msg.nodeId > nodeAmount && addNode(msg.buff[4], MAC, msg.nodeId));
			}
			ACK_or_NAK(MAC, stillAvailable);
			break;
		case 6:
			/* Received : PING
			 * Response : None, reset node PINGED status*/
			// Make sure the node exists
			if(msg.nodeId > nodeAmount) {
				alarm_noise(msg.nodeId);
				return;
			}
			// Make sure the secret matches
			if(msg.buff[4] != NODES[msg.nodeId].SECRET) {
				DUMP_int(NODES[msg.nodeId].SECRET);
				DUMP("ALARM - PING SECRET wrong\n");
				DUMP_int(msg.buff[4]);
				DUMP("\n");
				DUMP_int(NODES[msg.nodeId].SECRET);
			} else {
				NODES[msg.nodeId].PINGED = 0;
			}
			break;

	}
}
