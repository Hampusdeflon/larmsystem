#include <alarm.h>
#include <usart.h>
#include <gpio.h>

/* initiates LED to pin 3 on GPIOE (PE3) as output.
 * @author Hampus de Flon
 * */
void gpio_start_alarm(void) {
	
	GPIO_InitTypeDef GPIO_init_structure;

	GPIO_StructInit(&GPIO_init_structure);

	GPIO_DeInit(GPIOE); 
	
	//Connect LED to pin : PE3
	//LED - output
	GPIO_init_structure.GPIO_Pin   = GPIO_Pin_3;
	GPIO_init_structure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_init_structure.GPIO_OType = GPIO_OType_PP;							
	GPIO_init_structure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_init_structure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOE, &GPIO_init_structure);
} 

/* Turns on LED which is synonym with triggered alarm
 * @author Hampus de Flon  & Houmam
 * */
void start_alarm(void) {
	central_alarm_on = 1;
	gpio_start_alarm();
	GPIO_WriteBit(GPIOE,LED_pin, Bit_SET); //turn on led
}

void ping_start_alarm(void) {
	gpio_start_alarm();
	GPIO_WriteBit(GPIOE,LED_pin, Bit_SET); //turn on led
}

/* Turns off LED which is synonym with alarm disabled
 * @author Hampus de Flon & Houmam
 * */
void disable_alarm(void) {

	DUMP("\nalarm disabled");
	send_alarm_ack();
	central_alarm_on = 0;
	GPIO_WriteBit(GPIOE,LED_pin, Bit_RESET); //turn off led

}

void ping_disable_alarm(void) {

	DUMP("\nalarm disabled");
	central_alarm_on = 0;
	GPIO_WriteBit(GPIOE,LED_pin, Bit_RESET); //turn off led

}