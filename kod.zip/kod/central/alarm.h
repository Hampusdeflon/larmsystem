#include <stdint.h>

#define LED_pin GPIO_Pin_3

uint8_t central_alarm_on;

void CANMsg_fault_alarm(uint8_t nodeId, char invalidMsg[]);
