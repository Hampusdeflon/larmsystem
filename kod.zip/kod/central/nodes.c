#include "nodes.h"
#include <central.h>
#include <debug.h>

/*Find node by MAC
 * @param MAC An address of 4 bytes
 * @return position of node or 0
 * @author Martin Engström*/
uint8_t find_node_by_MAC(uint8_t MAC[])
{
	for(uint8_t i = 1; i <= nodeAmount; i++) {
		NODE *a = &NODES[i];
		if(compareArrays(a->MAC, MAC, 4)) {
			return i;
		}
	}
	return 0;
}

/*Add new node to the end of linked list of nodes
 * @param node Pointer to a potential new node
 * @return nodeId
 * @author Houmam, Martin engström*/
uint8_t addNode(enum PERIPHERAL_TYPE node_type, uint8_t MAC[], uint8_t nodeId)
{
	if(nodeAmount < 30) {
		// Increment nodeAmount
		nodeAmount++;
		// Set the new node to be equal to the parameter node
		NODES[nodeAmount].node_type = node_type;
		NODES[nodeAmount].nodeId = nodeId;
		NODES[nodeAmount].alarm_triggered = 0;
		NODES[nodeAmount].alarm_on = 0;
		NODES[nodeAmount].PINGED = 0;
		copyArray(NODES[nodeAmount].MAC, MAC, 4);
		if(node_type == MOTION_SENSOR_ALARM) {
			conf.connected_m_alarm++;
		} else {
			conf.connected_d_alarm++;
		}
		DUMP("\nAdding Node: ");
		DUMP_int(nodeId);
		return 1;
	}
	return 0;
}

