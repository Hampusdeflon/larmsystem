#include <stdint.h>
#include "can_central.h"
#include "usart.h"
#include "central.h"
#include "alarm.h"
#include "door_alarm.h"
#include "can_door_alarm.h"
/*
 * 	startup.c
 *
 */



__attribute__((naked)) __attribute__((section (".start_section")) )
void startup ( void )
{
	__asm__ volatile(" LDR R0,=0x2001C000\n");		/* set stack */
	__asm__ volatile(" MOV SP,R0\n");
	__asm__ volatile(" BL main\n");					/* call main */
	__asm__ volatile(".L1: B .L1\n");				/* never return */
}


/*typedef struct {
	uint8_t doorId;
	uint8_t doorOpen; // 0:false, 1:true
	uint8_t duration; // The time a door can be open
	uint8_t alarm_status; // 0:Off, 1:On
} *PDoor;
typedef struct {
	uint8_t PIN;
	uint8_t nodeId;
	PDoor doors[10]; // List of doors
} *PD_alarm;
typedef struct {
} *PUnit_table;
*/



uint8_t pin;

void central_config(void)
{
	
	// Reset data
	conf.expected_d_alarm = 0;
	conf.expected_m_alarm = 0;
	conf.connected_d_alarm = 0;
	conf.connected_m_alarm = 0;
	// Setup a pin-code and echo numbers
	uint16_t bytes[4];
	DUMP("\nSet PIN-code (Enter 4-digits)\n>> ");
	bytes[0] = _getdigit() * 1000;
	DUMP_int(bytes[0]/1000);
	bytes[1] = _getdigit() * 100;
	DUMP_int(bytes[1]/100);
	bytes[2] = _getdigit() * 10;
	DUMP_int(bytes[2]/10);
	bytes[3] = _getdigit();
	DUMP_int(bytes[3]);
	uint16_t PIN = bytes[0] + bytes[1] + bytes[2] + bytes[3];
	
	/*pin = _getint();*/
	conf.PIN = PIN;
	pin = PIN;
	// Respond with the PIN
	DUMP("\nPIN = ");
	DUMP_int(conf.PIN);

	// Choose a standard configuration and echo
	DUMP("\n\nChoose standard configuration 1-5\n");
	DUMP("\n1: Motion Alarm 1 | Door Alarm 1");
	DUMP("\n2: Motion Alarm 2 | Door Alarm 0");
	DUMP("\n3: Motion Alarm 0 | Door Alarm 2\n");
	DUMP("\n4: Motion Alarm 1 | Door Alarm 0");
	DUMP("\n5: Motion Alarm 0 | Door Alarm 1\n");
	DUMP(">> ");
	uint8_t configuration = _getdigit();
	DUMP_int(configuration);

	// Respond with the configuration selected
	DUMP("\nStandard configuration ");
	DUMP_int(configuration);
	DUMP(" selected.\n");

	// Set config data
	switch(configuration) {
		case 1:
			conf.expected_d_alarm = 1;
			conf.expected_m_alarm = 1;
			break;
		case 2:
			conf.expected_d_alarm = 0;
			conf.expected_m_alarm = 2;
			break;
		case 3:
			conf.expected_d_alarm = 2;
			conf.expected_m_alarm = 0;
			break;
		case 4:
			conf.expected_d_alarm = 0;
			conf.expected_m_alarm = 1;
			break;
		case 5:
			conf.expected_d_alarm = 1;
			conf.expected_m_alarm = 0;
			break;
	}

	//set motion sensor sensitivity
	uint8_t index = conf.expected_m_alarm;


	while (index > 0) {

		DUMP("\nEnter motion sensors sensitivity in cm (from 00 to 99)\n>> ");
		uint8_t sens_digit1 = _getdigit();
		DUMP_int(sens_digit1);
		uint8_t sens_digit2 = _getdigit();
		DUMP_int(sens_digit2);
		uint8_t motion_sensor_sens = (sens_digit1 * 10) + sens_digit2;

		// Respond with the sensitivity
		DUMP("\nMotion sensor sensitivity = ");
		DUMP_int(motion_sensor_sens);
		send_motion_msg(motion_sensor_sens);
		index--;
	}


	index = conf.expected_d_alarm;
	while(index > 0) {
		DOOR_ALARM_CONFIG door_alarm_config;

		DUMP("\nEnter number of doors being used to be enabled (max 10):\n");

		uint16_t num_enable_doors = _getint();

		if (num_enable_doors > 10) num_enable_doors = 10;
		door_alarm_config.enable_doors = 0;
		for (uint8_t i = 0; i < num_enable_doors; i++) {
			door_alarm_config.enable_doors |= 1 << i;
		}


		DUMP("\nEnter the amount of time a door is allowed to be open (seconds):\n");
		uint8_t open_door_s = _getint();
		door_alarm_config.open_door_s = open_door_s;

		DUMP("\nEnter the duration of the local alarm until the central alarm is activated (seconds):\n");
		uint8_t local_alarm_s = _getint();
		door_alarm_config.local_alarm_s = local_alarm_s;

		send_door_msg(&door_alarm_config);

		DUMP("\nDoor Alarm setup completed.");
		index--;
	}

	// Give the peripherals the ready-signal to connect
	READY();
	// Wait for all nodes to connect before continuing main program
	while(conf.expected_d_alarm > conf.connected_d_alarm ||
	      conf.expected_m_alarm > conf.connected_m_alarm);
	DUMP("\n");
	DUMP_int(conf.connected_d_alarm);
	DUMP(" door alarms connected!\n");
	DUMP_int(conf.connected_m_alarm);
	DUMP(" motion alarms connected!\n");
	DUMP("\n\nALARM SYSTEM ACTIVE\n\n");
}

void init_central(void)
{
	// Reset memory
	nodeAmount = 0;
	// Initiate USART
	USART_Cmd(USART1, ENABLE);
	DUMP("\nUsart1 enabled.");
	// Initiate CAN1
	can1_init(central_can_receiver);
}



void main(void)
{
	init_central();
	central_config();
	TIMERS_InitTIM(2, 42000, 1000, PING_ALL);
	central_alarm_on = 0;
	uint8_t PIN_attempts = MAX_PIN_ATTEMPTS;
	while(1) {
		//Keypad
		while(central_alarm_on && PIN_attempts > 0) {
			DUMP("\nInput PIN to disable alarm");
			DUMP("\nEnter PIN >>");
			keypad_init();
			uint8_t keypad_input;
			uint16_t input_PIN[4];
			uint8_t counter = 0;
			uint16_t keypad_PIN = 0;
			while(1) {
				keypad_input = getKey();

				if(keypad_input != 255) {
					input_PIN[counter++] = keypad_input;
					keypad_input += '0';
					DUMP(&keypad_input);
				}
				if (counter == 4) {
					keypad_PIN = ((input_PIN[0] ) * 1000) + ((input_PIN[1] ) * 100) + ((input_PIN[2] ) * 10) + input_PIN[3];
				}
				if(PIN_attempts == 0) {
					DUMP("\nPIN entered incorrectly too many times");
					break;
				}


				//if correct PIN disable alarm else decrement PIN_attempts

				if( keypad_PIN != 0) {		//if input is an PIN-code
					if(keypad_PIN != conf.PIN ) {
						keypad_PIN = 0;
						PIN_attempts--;
						counter = 0;
						DUMP("\nIncorrect Pin entered! Num of attempts left: ");
						DUMP_int(PIN_attempts);
						DUMP("\nEnter PIN >>");
						/*DUMP_int(conf.PIN);
						DUMP("\n");
						DUMP_int(pin);
						DUMP("\n");*/
					} else if(keypad_PIN == conf.PIN) {
						DUMP("\nCorrect Pin Entered.");
						PIN_attempts = MAX_PIN_ATTEMPTS;
						disable_alarm();
						counter = 0;
						break;
					}
				}
			}
		}
	}

}
